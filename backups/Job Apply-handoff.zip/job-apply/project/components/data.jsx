// Seed data

const JOBS = [
  {
    id: 'j1', title: 'Senior Product Designer, Platform', company: 'Linear Orbit',
    location: 'San Francisco · Remote OK', postedAt: '2h ago', postedRank: 10,
    score: 94, isNew: true,
    reasons: [
      { kind: 'skill', label: 'Design systems · 7y' },
      { kind: 'exp',   label: 'Platform UX' },
      { kind: 'loc',   label: 'Remote-friendly' },
    ],
  },
  {
    id: 'j2', title: 'Principal Designer, AI Products', company: 'Harbor AI',
    location: 'Remote, US', postedAt: '4h ago', postedRank: 9,
    score: 91, isNew: true,
    reasons: [
      { kind: 'skill', label: 'AI product UX' },
      { kind: 'skill', label: 'Prototyping in code' },
      { kind: 'exp',   label: '10+ yrs leadership' },
      { kind: 'loc',   label: 'Fully remote' },
    ],
  },
  {
    id: 'j3', title: 'Staff UX Researcher', company: 'Northwind Health',
    location: 'New York — Hybrid', postedAt: '6h ago', postedRank: 8,
    score: 88, isNew: true,
    reasons: [
      { kind: 'skill', label: 'Mixed-methods research' },
      { kind: 'exp',   label: 'Healthcare · 4y' },
      { kind: 'neg',   label: 'On-site 3d/wk' },
    ],
  },
  {
    id: 'j4', title: 'Senior Designer, Growth', company: 'Fernway',
    location: 'Austin · Remote OK', postedAt: '1d ago', postedRank: 7,
    score: 82,
    reasons: [
      { kind: 'skill', label: 'Growth experimentation' },
      { kind: 'exp',   label: 'B2C marketplace' },
    ],
  },
  {
    id: 'j5', title: 'Lead Designer, Design Systems', company: 'Quillford',
    location: 'Remote, Americas', postedAt: '1d ago', postedRank: 6,
    score: 79,
    reasons: [
      { kind: 'skill', label: 'Tokens & theming' },
      { kind: 'exp',   label: 'Multi-brand systems' },
    ],
  },
  {
    id: 'j6', title: 'Product Designer II', company: 'Pallet & Co.',
    location: 'Remote, EU', postedAt: '2d ago', postedRank: 4,
    score: 71,
    reasons: [
      { kind: 'skill', label: 'SaaS dashboards' },
      { kind: 'neg',   label: 'EU hours' },
    ],
  },
];

const APPS = [
  { id: 'a1', title: 'Senior Product Designer, Growth', company: 'Cedar Labs',  stage: 'interview', when: 'Today'     },
  { id: 'a2', title: 'Lead Designer, Mobile',           company: 'Kite & Kin',  stage: 'screening', when: 'Today'     },
  { id: 'a3', title: 'Principal Designer, Platform',    company: 'Rivet Works', stage: 'offer',     when: '2 days ago'},
  { id: 'a4', title: 'Sr. UX Designer, Enterprise',     company: 'Marbletown',  stage: 'viewed',    when: 'Yesterday' },
  { id: 'a5', title: 'Staff Product Designer',          company: 'Northfield',  stage: 'submitted', when: 'Yesterday' },
  { id: 'a6', title: 'Senior Designer, Payments',       company: 'Tidecaster',  stage: 'rejected',  when: '3 days ago'},
];

const AGENTS = [
  { name: 'Scraper',  detail: 'Crawling 14 sources · 312 postings today', tone: 'success', accent: TOKENS.color.primary },
  { name: 'Analyzer', detail: 'Parsing job descriptions · 287 processed', tone: 'success', accent: 'oklch(0.55 0.20 290)' },
  { name: 'Matcher',  detail: 'Ranking fit against your profile',         tone: 'success', accent: 'oklch(0.55 0.18 160)' },
  { name: 'Applier',  detail: 'Waiting for queued matches',               tone: 'muted',   accent: TOKENS.color.warn },
];

Object.assign(window, { JOBS, APPS, AGENTS });
