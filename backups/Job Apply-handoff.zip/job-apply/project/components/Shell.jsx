// Formal header, footer, controls sheet, and Advanced tab

function Header({ tab, setTab, onOpenControls }) {
  const tabs = [
    { id: 'overview', label: 'Overview'     },
    { id: 'matches',  label: 'Matches'      },
    { id: 'apps',     label: 'Applications' },
  ];
  const [menuOpen, setMenuOpen] = React.useState(false);
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-[1120px] mx-auto flex items-center h-14 px-6 gap-6">
        <Logo/>
        <nav className="hidden md:flex items-center gap-1 ml-4">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`relative h-8 px-3 rounded-full text-[13px] font-medium transition ${
                tab === t.id ? 'text-slate-900' : 'text-slate-500 hover:text-slate-900'
              }`}>
              {t.label}
              {tab === t.id && <span className="absolute left-3 right-3 -bottom-[15px] h-[2px] rounded-full" style={{ background: TOKENS.color.primary }}/>}
            </button>
          ))}
        </nav>
        <div className="flex-1"/>
        <div className="hidden sm:flex items-center gap-1.5 text-[12px] text-slate-500">
          <StatusDot tone="success" pulse size={6}/>
          <span>System active</span>
        </div>
        <button onClick={onOpenControls}
          className="inline-flex items-center gap-1.5 h-8 px-3 rounded-full text-[12.5px] text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition">
          <I.sliders s={14}/> Automation
        </button>
        <IconBtn title="Notifications"><I.bell s={16}/></IconBtn>
        <div className="relative">
          <button onClick={() => setMenuOpen(v => !v)}
            className="inline-flex items-center gap-2 pl-1 pr-2 h-9 rounded-full hover:bg-slate-100 transition">
            <span className="h-7 w-7 rounded-full bg-slate-900 text-white text-[11.5px] inline-flex items-center justify-center font-semibold">AM</span>
            <I.chev s={12}/>
          </button>
          {menuOpen && (
            <div onMouseLeave={() => setMenuOpen(false)} className="absolute right-0 top-11 w-56 rounded-xl bg-white border border-slate-200 shadow-lg overflow-hidden">
              <div className="px-3 py-3 border-b border-slate-100">
                <div className="text-[13px] font-medium text-slate-900">Alex Morgan</div>
                <div className="text-[12px] text-slate-500">alex@example.com</div>
              </div>
              <button className="w-full text-left px-3 py-2 text-[13px] hover:bg-slate-50">Profile & preferences</button>
              <button className="w-full text-left px-3 py-2 text-[13px] hover:bg-slate-50">CV & cover letter</button>
              <button className="w-full text-left px-3 py-2 text-[13px] hover:bg-slate-50">Billing</button>
              <div className="border-t border-slate-100"/>
              <button className="w-full text-left px-3 py-2 text-[13px] text-rose-600 hover:bg-rose-50">Sign out</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="max-w-[1120px] mx-auto px-6 py-6 flex items-center justify-between text-[11.5px] text-slate-400 border-t border-slate-100 mt-10">
      <div className="inline-flex items-center gap-2">
        <span>v1.3.0</span>
        <span className="text-slate-300">·</span>
        <span className="inline-flex items-center gap-1.5"><StatusDot tone="success" pulse size={5}/> All systems operational</span>
      </div>
      <div className="inline-flex items-center gap-4">
        <a href="#" onClick={e=>e.preventDefault()} className="hover:text-slate-700">Help</a>
        <a href="#" onClick={e=>e.preventDefault()} className="hover:text-slate-700">Privacy</a>
        <a href="#" onClick={e=>e.preventDefault()} className="hover:text-slate-700">Contact</a>
      </div>
    </footer>
  );
}

function ControlsSheet({ open, onClose, settings, setSettings }) {
  if (!open) return null;
  const set = (patch) => setSettings({ ...settings, ...patch });
  const dailyPct = Math.round((settings.dailyUsed / settings.dailyLimit) * 100);

  return (
    <div className="fixed inset-0 z-50" onClick={onClose}>
      <div className="absolute inset-0 bg-slate-900/10 backdrop-blur-[2px]"/>
      <aside onClick={e=>e.stopPropagation()}
        className="absolute right-0 top-0 bottom-0 w-full max-w-[420px] bg-white border-l border-slate-200 shadow-xl overflow-y-auto">
        <div className="flex items-center justify-between px-6 h-14 border-b border-slate-100">
          <h3 className="text-[15px] font-semibold text-slate-900">Automation</h3>
          <IconBtn onClick={onClose} title="Close"><I.x s={14}/></IconBtn>
        </div>
        <div className="p-6 space-y-7">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[14.5px] font-semibold text-slate-900">Auto-Apply</div>
              <p className="text-[12.5px] text-slate-500 mt-1 max-w-[30ch]">Submit applications automatically for strong matches.</p>
            </div>
            <Toggle on={settings.autoApply} onChange={v => set({ autoApply: v })}/>
          </div>

          <div>
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-[13.5px] font-medium text-slate-900">Daily limit</span>
              <span className="text-[12.5px] text-slate-500 tabular-nums">
                <span className="text-slate-900 font-medium">{settings.dailyUsed}</span> of {settings.dailyLimit} used
              </span>
            </div>
            <div className="h-1 rounded-full bg-slate-100 overflow-hidden mb-3">
              <div className="h-full rounded-full" style={{ width: `${dailyPct}%`, background: TOKENS.color.primary }}/>
            </div>
            <input type="range" min={5} max={50} step={1} value={settings.dailyLimit}
              onChange={e => set({ dailyLimit: Number(e.target.value) })}
              className="w-full"/>
          </div>

          <div>
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-[13.5px] font-medium text-slate-900">Minimum match score</span>
              <span className="text-[13px] text-slate-900 tabular-nums font-medium">{settings.threshold}</span>
            </div>
            <input type="range" min={50} max={100} step={1} value={settings.threshold}
              onChange={e => set({ threshold: Number(e.target.value) })}
              className="w-full"/>
            <p className="text-[12px] text-slate-500 mt-2">Below this, matches wait for your review.</p>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-4">
            <ToggleRow label="Tailor cover letter to each job"       on={settings.tailor}     onChange={v=>set({tailor:v})}/>
            <ToggleRow label="Skip companies I already applied to"   on={settings.skipDup}    onChange={v=>set({skipDup:v})}/>
            <ToggleRow label="Pause if I get rejected today"         on={settings.pauseOnRej} onChange={v=>set({pauseOnRej:v})}/>
          </div>
        </div>
      </aside>
    </div>
  );
}

function ToggleRow({ label, on, onChange }) {
  return (
    <label className="flex items-center justify-between gap-4">
      <span className="text-[13px] text-slate-800">{label}</span>
      <Toggle on={on} onChange={onChange}/>
    </label>
  );
}

Object.assign(window, { Header, Footer, ControlsSheet });
