// Main composition

function App() {
  const [tab,      setTab]      = React.useState('overview');
  const [jobs,     setJobs]     = React.useState(JOBS);
  const [apps]                   = React.useState(APPS);
  const [savedIds, setSavedIds] = React.useState(['j2']);
  const [controlsOpen, setControlsOpen] = React.useState(false);
  const [settings, setSettings] = React.useState({
    autoApply: true,
    threshold: 85,
    dailyLimit: 15,
    dailyUsed: 8,
    tailor: true,
    skipDup: true,
    pauseOnRej: false,
  });
  const [tweaks, setTweaks] = React.useState(window.TWEAK_DEFAULTS || {
    accent: 'indigo', compact: false,
  });

  React.useEffect(() => {
    const map = {
      indigo: 'oklch(0.52 0.16 255)',
      green:  'oklch(0.58 0.14 155)',
      ink:    '#0F172A',
      violet: 'oklch(0.52 0.18 290)',
    };
    TOKENS.color.primary = map[tweaks.accent] || map.indigo;
    document.documentElement.style.setProperty('--ja-primary', map[tweaks.accent] || map.indigo);
  }, [tweaks.accent]);

  const onApply = (id) => {
    setJobs(jobs.filter(j => j.id !== id));
    setSavedIds(savedIds.filter(s => s !== id));
    setSettings(s => ({ ...s, dailyUsed: Math.min(s.dailyLimit, s.dailyUsed + 1) }));
  };
  const onSave = (id) => setSavedIds(savedIds.includes(id) ? savedIds.filter(s => s !== id) : [...savedIds, id]);
  const onReviewCV = () => {};
  const onDismiss  = (id) => setJobs(jobs.filter(j => j.id !== id));

  const onGo = (t) => {
    if (t === 'prefs') setControlsOpen(true);
    else setTab(t);
  };

  const stats = {
    newMatches: jobs.filter(j => j.isNew).length,
    active:     apps.filter(a => !['rejected','offer'].includes(a.stage)).length + apps.filter(a => a.stage === 'offer').length,
    interviews: apps.filter(a => a.stage === 'interview' || a.stage === 'offer').length,
    replyRate:  Math.round((apps.filter(a => ['viewed','screening','interview','offer'].includes(a.stage)).length / apps.length) * 100),
  };

  return (
    <div className="min-h-screen" style={{ background: TOKENS.color.bg }}>
      <Header tab={tab} setTab={setTab} onOpenControls={() => setControlsOpen(true)}/>

      <main className="max-w-[1120px] mx-auto px-6 py-8">
        {tab === 'overview' && (
          <Overview
            stats={stats} agents={AGENTS} jobs={jobs} savedIds={savedIds}
            settings={settings}
            onApply={onApply} onSave={onSave} onReviewCV={onReviewCV} onGo={onGo}/>
        )}
        {tab === 'matches' && (
          <MatchFeed jobs={jobs} savedIds={savedIds}
            onApply={onApply} onSave={onSave} onReviewCV={onReviewCV} onDismiss={onDismiss}/>
        )}
        {tab === 'apps' && (
          <Tracker apps={apps}/>
        )}
      </main>

      <Footer/>

      <ControlsSheet open={controlsOpen} onClose={() => setControlsOpen(false)} settings={settings} setSettings={setSettings}/>
      <Tweaks tweaks={tweaks} setTweaks={setTweaks}/>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
