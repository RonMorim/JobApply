// Tweaks — minimal

function Tweaks({ tweaks, setTweaks }) {
  const [open, setOpen] = React.useState(false);
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === '__activate_edit_mode')   { setVisible(true); setOpen(true); }
      if (e.data?.type === '__deactivate_edit_mode') { setVisible(false); setOpen(false); }
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  const persist = (patch) => {
    const next = { ...tweaks, ...patch };
    setTweaks(next);
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: patch }, '*');
  };

  if (!visible) return null;

  const accents = [
    { id: 'indigo', label: 'Trust',    color: 'oklch(0.52 0.16 255)' },
    { id: 'green',  label: 'Success',  color: 'oklch(0.58 0.14 155)' },
    { id: 'ink',    label: 'Ink',      color: '#0F172A' },
    { id: 'violet', label: 'Focus',    color: 'oklch(0.52 0.18 290)' },
  ];

  return (
    <div className="fixed bottom-5 right-5 z-50">
      {open ? (
        <div className="w-[260px] rounded-2xl bg-white border border-slate-200 shadow-xl overflow-hidden">
          <div className="flex items-center justify-between px-4 h-10 border-b border-slate-100">
            <div className="text-[12.5px] font-semibold text-slate-900">Tweaks</div>
            <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-slate-900"><I.x s={12}/></button>
          </div>
          <div className="p-4 space-y-4">
            <div>
              <div className="text-[11px] uppercase tracking-wider text-slate-500 font-medium mb-2">Accent</div>
              <div className="grid grid-cols-4 gap-1.5">
                {accents.map(a => (
                  <button key={a.id} onClick={() => persist({ accent: a.id })}
                    className={`rounded-xl border p-2 flex flex-col items-center gap-1.5 transition ${tweaks.accent === a.id ? 'border-slate-900' : 'border-slate-200'}`}>
                    <span className="h-5 w-5 rounded-full" style={{ background: a.color }}/>
                    <span className="text-[10px] text-slate-600">{a.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <label className="flex items-center justify-between text-[13px] text-slate-800">
              <span>Compact spacing</span>
              <Toggle on={tweaks.compact} onChange={v => persist({ compact: v })}/>
            </label>
            <label className="flex items-center justify-between text-[13px] text-slate-800">
              <span>Show system bar</span>
              <Toggle on={tweaks.showSystemBar} onChange={v => persist({ showSystemBar: v })}/>
            </label>
          </div>
        </div>
      ) : (
        <button onClick={() => setOpen(true)} className="h-10 px-4 rounded-full bg-slate-900 text-white text-[13px] font-medium shadow-lg inline-flex items-center gap-1.5">
          <I.settings s={14}/> Tweaks
        </button>
      )}
    </div>
  );
}

Object.assign(window, { Tweaks });
