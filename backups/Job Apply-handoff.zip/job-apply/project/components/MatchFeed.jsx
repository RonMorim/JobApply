// Compact match cards with gradient score ring

function ScoreRing({ score, size = 48 }) {
  const stroke = 4;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, score)) / 100;
  // Hue-mapped gradient: high = green→blue, mid = blue→violet, low = amber→rose
  const [from, to] =
    score >= 85 ? ['oklch(0.72 0.15 160)', 'oklch(0.55 0.18 240)'] :
    score >= 70 ? ['oklch(0.62 0.18 260)', 'oklch(0.58 0.20 300)'] :
    score >= 55 ? ['oklch(0.78 0.14 80)',  'oklch(0.66 0.18 40)']  :
                  ['oklch(0.70 0.14 40)',  'oklch(0.60 0.18 20)'];
  const gid = `ring-${score}-${Math.floor(Math.random() * 99999)}`;
  const textColor = score >= 85 ? 'oklch(0.38 0.10 200)'
                 : score >= 70 ? 'oklch(0.38 0.14 275)'
                 : score >= 55 ? 'oklch(0.40 0.12 60)'
                 : 'oklch(0.40 0.14 25)';
  return (
    <div className="relative inline-flex shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={from}/>
            <stop offset="100%" stopColor={to}/>
          </linearGradient>
        </defs>
        <circle cx={size/2} cy={size/2} r={r} stroke="#EEF0F3" strokeWidth={stroke} fill="none"/>
        <circle cx={size/2} cy={size/2} r={r} stroke={`url(#${gid})`} strokeWidth={stroke} fill="none"
          strokeDasharray={c} strokeDashoffset={c * (1 - pct)} strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 700ms cubic-bezier(.22,1,.36,1)' }}/>
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[14px] font-semibold tabular-nums leading-none" style={{ color: textColor, fontFeatureSettings: '"tnum"' }}>
          {score}
        </span>
      </div>
    </div>
  );
}

const REASON_TONES = {
  skill: { bg: 'oklch(0.97 0.03 155)', fg: 'oklch(0.38 0.11 155)', icon: I.skill },
  exp:   { bg: 'oklch(0.97 0.02 255)', fg: 'oklch(0.38 0.14 255)', icon: I.exp   },
  loc:   { bg: 'oklch(0.97 0.03 295)', fg: 'oklch(0.40 0.14 295)', icon: I.loc   },
  neg:   { bg: 'oklch(0.98 0.02 25)',  fg: 'oklch(0.48 0.12 25)',  icon: I.warn  },
};

function ReasonTag({ reason }) {
  const t = REASON_TONES[reason.kind] || REASON_TONES.skill;
  const Icon = t.icon;
  return (
    <span className="inline-flex items-center gap-1 h-5 px-1.5 rounded-md text-[11px] font-medium"
          style={{ background: t.bg, color: t.fg }}>
      <Icon s={10}/>
      {reason.label}
    </span>
  );
}

function MatchCard({ job, saved, onApply, onSave, onReviewCV, onDismiss }) {
  return (
    <article
      className="group rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-colors"
      style={{ boxShadow: '0 1px 2px rgba(15,23,42,0.03)' }}
    >
      <div className="px-4 py-3 flex items-center gap-4">
        <ScoreRing score={job.score}/>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            <h3 className="text-[14.5px] font-semibold text-slate-900 tracking-tight truncate">
              {job.isNew && (
                <span className="inline-block h-1.5 w-1.5 rounded-full align-middle mr-2 -translate-y-[2px]"
                      style={{ background: TOKENS.color.primary }} title="New today"/>
              )}
              {job.title}
            </h3>
          </div>
          <div className="text-[12.5px] text-slate-500 mt-0.5 truncate">
            <span className="text-slate-700 font-medium">{job.company}</span>
            <span className="text-slate-300 mx-1.5">·</span>
            {job.location}
            <span className="text-slate-300 mx-1.5">·</span>
            <span className="tabular-nums">{job.postedAt}</span>
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {job.reasons.map((r, i) => <ReasonTag key={i} reason={r}/>)}
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => onReviewCV(job.id)}
            className="hidden sm:inline-flex h-8 px-3 rounded-full text-[12.5px] font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 items-center gap-1.5 transition"
            title="Review tailored CV"
          >
            <I.file s={12}/> Review CV
          </button>
          <button
            onClick={() => onSave(job.id)}
            className={`inline-flex h-8 w-8 items-center justify-center rounded-full transition ${saved ? 'text-slate-900' : 'text-slate-400 hover:text-slate-900 hover:bg-slate-100'}`}
            title={saved ? 'Saved' : 'Save'}
          >
            <I.bookmark s={14} filled={saved}/>
          </button>
          <button
            onClick={() => onApply(job.id)}
            className="inline-flex h-8 px-3.5 rounded-full text-[12.5px] font-semibold text-white transition active:scale-[0.98]"
            style={{ background: TOKENS.color.primary }}
          >
            Apply
          </button>
        </div>
      </div>
    </article>
  );
}

function FilterBar({ filter, setFilter, sort, setSort, count }) {
  const tabs = [
    { id: 'all',    label: 'All' },
    { id: 'new',    label: 'New' },
    { id: 'strong', label: 'Strong (85+)' },
    { id: 'remote', label: 'Remote' },
    { id: 'saved',  label: 'Saved' },
  ];
  return (
    <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
      <div className="flex items-center gap-0.5">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setFilter(t.id)}
            className={`h-8 px-3 rounded-full text-[12.5px] font-medium transition ${
              filter === t.id
                ? 'bg-slate-900 text-white'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
            }`}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="flex items-center gap-2">
        <span className="text-[12px] text-slate-400 tabular-nums">{count} results</span>
        <div className="relative">
          <select value={sort} onChange={e => setSort(e.target.value)}
            className="appearance-none h-8 pl-3 pr-8 rounded-full border border-slate-200 bg-white text-[12.5px] text-slate-700 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-200">
            <option value="match">Sort: Match score</option>
            <option value="newest">Sort: Newest</option>
            <option value="oldest">Sort: Oldest</option>
          </select>
          <span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-slate-400"><I.chev s={12}/></span>
        </div>
      </div>
    </div>
  );
}

function MatchFeed({ jobs, savedIds, onApply, onSave, onReviewCV, onDismiss, embedded }) {
  const [filter, setFilter] = React.useState('all');
  const [sort,   setSort]   = React.useState('match');

  let list = jobs.filter(j => {
    if (filter === 'new')    return j.isNew;
    if (filter === 'strong') return j.score >= 85;
    if (filter === 'remote') return /remote/i.test(j.location);
    if (filter === 'saved')  return savedIds.includes(j.id);
    return true;
  });
  list = [...list].sort((a,b) => sort === 'match' ? b.score - a.score : sort === 'newest' ? b.postedRank - a.postedRank : a.postedRank - b.postedRank);

  return (
    <section>
      {!embedded && (
        <header className="mb-4">
          <h2 className="text-[20px] font-semibold text-slate-900 tracking-tight">Your matches</h2>
          <p className="text-[13px] text-slate-500 mt-0.5">Ranked by fit to your profile. Updated continuously.</p>
        </header>
      )}
      <FilterBar filter={filter} setFilter={setFilter} sort={sort} setSort={setSort} count={list.length}/>
      <div className="space-y-2">
        {list.map(j => (
          <MatchCard key={j.id} job={j}
            saved={savedIds.includes(j.id)}
            onApply={onApply}
            onSave={onSave}
            onReviewCV={onReviewCV}
            onDismiss={onDismiss}/>
        ))}
        {list.length === 0 && (
          <div className="py-10 text-center text-[13px] text-slate-400">No matches in this view yet.</div>
        )}
      </div>
    </section>
  );
}

Object.assign(window, { MatchFeed, ScoreRing, MatchCard });
