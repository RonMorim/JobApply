// Overview tab — KPIs, capabilities, live agent activity, quick actions

function KPI({ label, value, sub, trend, accent }) {
  return (
    <div className="rounded-xl bg-white border border-slate-200 p-4" style={{ boxShadow: '0 1px 2px rgba(15,23,42,0.03)' }}>
      <div className="flex items-center justify-between">
        <span className="text-[11.5px] uppercase tracking-[0.12em] text-slate-500 font-medium">{label}</span>
        <span className="h-1.5 w-1.5 rounded-full" style={{ background: accent }}/>
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="text-[28px] font-semibold text-slate-900 tabular-nums leading-none tracking-tight">{value}</span>
        {trend && (
          <span className="text-[12px] font-medium tabular-nums" style={{ color: TOKENS.color.success }}>
            {trend}
          </span>
        )}
      </div>
      <div className="text-[12.5px] text-slate-500 mt-1.5">{sub}</div>
    </div>
  );
}

function KPIRow({ stats }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <KPI label="New matches today"    value={stats.newMatches}    sub="Ranked by the Matcher"      trend="+6 vs yesterday" accent={TOKENS.color.primary}/>
      <KPI label="Active applications"  value={stats.active}        sub="In review, screening, or interview"                 accent="oklch(0.55 0.20 290)"/>
      <KPI label="Interviews landed"    value={stats.interviews}    sub="This month"                  trend="+2 this week"    accent={TOKENS.color.success}/>
      <KPI label="Response rate"        value={`${stats.replyRate}%`} sub="Of applications sent"                             accent={TOKENS.color.warn}/>
    </div>
  );
}

function AgentPulse({ name, detail, tone, accent }) {
  return (
    <div className="flex items-center gap-3 py-2.5">
      <div className="relative inline-flex h-8 w-8 items-center justify-center rounded-full shrink-0"
           style={{ background: `color-mix(in oklab, ${accent} 12%, white)`, color: accent }}>
        <StatusDot tone={tone} pulse={tone === 'success'} size={6}/>
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[13px] text-slate-900 font-medium">{name}</div>
        <div className="text-[12px] text-slate-500 truncate">{detail}</div>
      </div>
    </div>
  );
}

function CapabilitiesPanel({ agents }) {
  return (
    <div className="rounded-2xl p-5 border border-slate-200 relative overflow-hidden"
         style={{ background: 'linear-gradient(140deg, oklch(0.98 0.015 255) 0%, oklch(0.99 0.008 160) 100%)' }}>
      <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full opacity-70 blur-3xl"
           style={{ background: 'radial-gradient(circle, oklch(0.85 0.10 255) 0%, transparent 70%)' }}/>
      <div className="relative">
        <div className="flex items-center gap-2 mb-1">
          <I.spark s={14}/>
          <span className="text-[11.5px] uppercase tracking-[0.12em] text-slate-500 font-medium">Working on it</span>
        </div>
        <h3 className="text-[18px] font-semibold text-slate-900 tracking-tight">
          Job Apply is searching while you focus on what matters.
        </h3>
        <p className="text-[13.5px] text-slate-600 mt-1.5 max-w-[52ch] leading-relaxed">
          Four agents scan, analyze, rank, and apply to roles that fit your profile — quietly, in the background.
        </p>
        <div className="mt-4 divide-y divide-slate-100">
          {agents.map(a => <AgentPulse key={a.name} {...a}/>)}
        </div>
      </div>
    </div>
  );
}

function QuickActions({ newCount, savedCount, onGo }) {
  const items = [
    { id: 'review', label: `Review your ${newCount} new matches`, sub: 'Top matches this morning',  accent: TOKENS.color.primary, icon: I.spark,    tab: 'matches', filter: 'new' },
    { id: 'saved',  label: `Resume ${savedCount} saved jobs`,      sub: 'Continue where you left off', accent: 'oklch(0.55 0.20 290)', icon: I.bookmark, tab: 'matches', filter: 'saved' },
    { id: 'cv',     label: 'Update your CV',                       sub: 'Last edited 4 days ago',      accent: 'oklch(0.55 0.18 160)', icon: I.file,     tab: 'advanced' },
    { id: 'prefs',  label: 'Tune your preferences',                 sub: 'Salary, location, role',      accent: TOKENS.color.warn,      icon: I.sliders,  tab: 'prefs' },
  ];
  return (
    <div>
      <div className="flex items-baseline justify-between mb-3">
        <h3 className="text-[14.5px] font-semibold text-slate-900 tracking-tight">Quick actions</h3>
        <span className="text-[12px] text-slate-400">Recommended for you</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {items.map(it => {
          const Icon = it.icon;
          return (
            <button key={it.id}
              onClick={() => onGo(it.tab, it.filter)}
              className="group text-left rounded-xl border border-slate-200 bg-white px-4 py-3 hover:border-slate-300 transition flex items-center gap-3">
              <span className="inline-flex h-9 w-9 items-center justify-center rounded-full shrink-0"
                    style={{ background: `color-mix(in oklab, ${it.accent} 12%, white)`, color: it.accent }}>
                <Icon s={15}/>
              </span>
              <span className="flex-1 min-w-0">
                <span className="block text-[13.5px] font-medium text-slate-900">{it.label}</span>
                <span className="block text-[12px] text-slate-500">{it.sub}</span>
              </span>
              <span className="text-slate-300 group-hover:text-slate-900 transition"><I.arrow s={14}/></span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function UsageMeter({ used, limit }) {
  const pct = Math.round((used / limit) * 100);
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="flex items-center justify-between">
        <span className="text-[11.5px] uppercase tracking-[0.12em] text-slate-500 font-medium">Today's activity</span>
        <span className="text-[12px] text-slate-500 tabular-nums">{pct}%</span>
      </div>
      <div className="mt-2 flex items-baseline gap-1.5">
        <span className="text-[22px] font-semibold tabular-nums text-slate-900 leading-none">{used}</span>
        <span className="text-[13px] text-slate-400 tabular-nums">/ {limit} applications sent</span>
      </div>
      <div className="mt-3 h-1 rounded-full bg-slate-100 overflow-hidden">
        <div className="h-full rounded-full transition-all"
             style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${TOKENS.color.primary}, oklch(0.60 0.17 290))` }}/>
      </div>
      <div className="mt-2 text-[12px] text-slate-500">
        Auto-Apply will run again in <span className="tabular-nums text-slate-800 font-medium">12m 40s</span>.
      </div>
    </div>
  );
}

function Overview({ stats, agents, jobs, savedIds, onApply, onSave, onReviewCV, onGo, settings }) {
  const previewJobs = [...jobs].sort((a,b) => b.score - a.score).slice(0, 3);
  return (
    <div className="space-y-8">
      {/* Greeting row */}
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-[26px] font-semibold text-slate-900 tracking-tight">Good morning, Alex</h1>
          <p className="text-[14px] text-slate-500 mt-1">Here's what happened overnight.</p>
        </div>
      </div>

      <KPIRow stats={stats}/>

      {/* Capabilities + usage */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <CapabilitiesPanel agents={agents}/>
        </div>
        <div className="space-y-3">
          <UsageMeter used={settings.dailyUsed} limit={settings.dailyLimit}/>
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex items-center justify-between">
              <span className="text-[11.5px] uppercase tracking-[0.12em] text-slate-500 font-medium">Automation</span>
              <StatusDot tone={settings.autoApply ? 'success' : 'muted'} pulse={settings.autoApply} size={6}/>
            </div>
            <div className="mt-2 text-[14px] font-medium text-slate-900">
              Auto-Apply {settings.autoApply ? 'on' : 'off'}
            </div>
            <div className="text-[12.5px] text-slate-500">
              Submitting to matches scoring {settings.threshold}+.
            </div>
            <button onClick={() => onGo('prefs')}
              className="mt-3 inline-flex items-center gap-1 text-[12.5px] font-medium text-slate-700 hover:text-slate-900">
              Adjust preferences <I.arrow s={12}/>
            </button>
          </div>
        </div>
      </div>

      <QuickActions newCount={stats.newMatches} savedCount={savedIds.length || 3} onGo={onGo}/>

      {/* Top matches preview */}
      <div>
        <div className="flex items-baseline justify-between mb-3">
          <h3 className="text-[14.5px] font-semibold text-slate-900 tracking-tight">Top matches today</h3>
          <button onClick={() => onGo('matches')} className="text-[12.5px] text-slate-500 hover:text-slate-900 inline-flex items-center gap-1">
            See all matches <I.arrow s={12}/>
          </button>
        </div>
        <div className="space-y-2">
          {previewJobs.map(j => (
            <MatchCard key={j.id} job={j}
              saved={savedIds.includes(j.id)}
              onApply={onApply}
              onSave={onSave}
              onReviewCV={onReviewCV}
              onDismiss={()=>{}}/>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Overview, KPI });
