// Agent Status Center — 4 agents with live-feel state

function MiniBars({ values, color }) {
  const max = Math.max(...values, 1);
  return (
    <div className="flex items-end gap-[2px] h-6">
      {values.map((v, i) => (
        <div key={i} className="rounded-sm" style={{
          width: 4,
          height: `${Math.max(8, (v / max) * 100)}%`,
          background: color,
          opacity: 0.35 + (i / values.length) * 0.65,
        }}/>
      ))}
    </div>
  );
}

function AgentCard({ agent, pulse }) {
  const toneMap = {
    active: { tone: 'success', label: 'Active',     dot: 'success', pulse: true  },
    idle:   { tone: 'muted',   label: 'Idle',       dot: 'muted',   pulse: false },
    queued: { tone: 'warn',    label: 'Queued',     dot: 'warn',    pulse: false },
    error:  { tone: 'danger',  label: 'Error',      dot: 'danger',  pulse: true  },
    paused: { tone: 'muted',   label: 'Paused',     dot: 'muted',   pulse: false },
  };
  const s = toneMap[agent.state] || toneMap.idle;
  const accent = {
    Scraper:  TOKENS.color.primary,
    Analyzer: TOKENS.color.violet,
    Matcher:  TOKENS.color.success,
    Applier:  TOKENS.color.warn,
  }[agent.name] || TOKENS.color.primary;

  const IconComp = {
    Scraper: I.scraper, Analyzer: I.analyzer, Matcher: I.matcher, Applier: I.applier,
  }[agent.name] || I.scraper;

  return (
    <div className="rounded-xl bg-white border border-slate-200 p-4 hover:shadow-sm transition-shadow"
         style={{ boxShadow: TOKENS.shadow.card }}>
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2.5">
          <div className="inline-flex h-9 w-9 items-center justify-center rounded-lg"
               style={{ background: `${accent}14`, color: accent }}>
            <IconComp s={18}/>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[14px] font-semibold text-slate-900">{agent.name}</span>
              <span className="text-[11px] text-slate-400 font-mono">#{agent.id}</span>
            </div>
            <div className="text-[12px] text-slate-500">{agent.role}</div>
          </div>
        </div>
        <Pill tone={s.tone}>
          <StatusDot tone={s.dot} pulse={s.pulse} size={6}/>
          {s.label}
        </Pill>
      </div>

      <div className="mt-3 text-[12px] text-slate-600 min-h-[32px] leading-snug">
        {agent.state === 'active' && (
          <span>
            <span className="inline-block w-1 h-1 rounded-full mr-1.5 align-middle" style={{background: accent}}/>
            {agent.currentTask}
          </span>
        )}
        {agent.state === 'idle'   && <span className="text-slate-400">Waiting for upstream signal…</span>}
        {agent.state === 'queued' && <span>{agent.queueMsg}</span>}
        {agent.state === 'error'  && <span className="text-rose-600">{agent.errorMsg}</span>}
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-slate-100">
        <Metric label="Today"  value={agent.stats.today}  accent={accent} />
        <Metric label="Queue"  value={agent.stats.queue}  accent={accent} />
        <div>
          <div className="text-[10.5px] uppercase tracking-wider text-slate-400 font-medium mb-1">Throughput</div>
          <MiniBars values={agent.stats.spark} color={accent}/>
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value, accent }) {
  return (
    <div>
      <div className="text-[10.5px] uppercase tracking-wider text-slate-400 font-medium mb-1">{label}</div>
      <div className="text-[18px] font-semibold text-slate-900 font-mono tabular-nums leading-none">{value}</div>
    </div>
  );
}

function AgentPipeline({ agents }) {
  // Arrow pipeline under the grid
  return (
    <div className="flex items-center gap-1 text-[11px] text-slate-500 px-0.5 pt-1">
      {agents.map((a, i) => (
        <React.Fragment key={a.id}>
          <span className="flex items-center gap-1">
            <StatusDot
              tone={a.state === 'active' ? 'success' : a.state === 'error' ? 'danger' : a.state === 'queued' ? 'warn' : 'muted'}
              pulse={a.state === 'active' || a.state === 'error'} size={6}/>
            <span className="font-medium text-slate-600">{a.name}</span>
          </span>
          {i < agents.length - 1 && <span className="text-slate-300 mx-1">→</span>}
        </React.Fragment>
      ))}
      <span className="ml-auto text-slate-400 font-mono tabular-nums">pipeline v1.2 · last sync 14:32:07</span>
    </div>
  );
}

function AgentStatusCenter({ agents }) {
  return (
    <section>
      <SectionHeader
        title="Agent Status Center"
        subtitle="Live state of the 4-stage automation pipeline"
        right={
          <div className="flex items-center gap-2">
            <Pill tone="success"><StatusDot tone="success" pulse size={6}/> All systems nominal</Pill>
            <Button variant="secondary" size="sm" icon={<I.settings s={14}/>}>Configure</Button>
          </div>
        }
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
        {agents.map(a => <AgentCard key={a.id} agent={a}/>)}
      </div>
      <AgentPipeline agents={agents}/>
    </section>
  );
}

function SectionHeader({ title, subtitle, right }) {
  return (
    <div className="flex items-end justify-between mb-3">
      <div>
        <h2 className="text-[15px] font-semibold text-slate-900 tracking-tight">{title}</h2>
        {subtitle && <p className="text-[12.5px] text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

Object.assign(window, { AgentStatusCenter, AgentCard, SectionHeader });
