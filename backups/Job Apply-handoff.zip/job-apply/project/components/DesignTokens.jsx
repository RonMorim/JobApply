// Minimal design tokens

const TOKENS = {
  color: {
    bg:      '#FBFBFA',
    surface: '#FFFFFF',
    ink:     '#0F172A',
    ink2:    '#334155',
    muted:   '#64748B',
    subtle:  '#94A3B8',
    line:    '#ECECEA',
    lineSoft:'#F2F2F0',
    primary: 'oklch(0.52 0.16 255)',
    primarySoft: 'oklch(0.96 0.02 255)',
    success: 'oklch(0.65 0.13 155)',
    warn:    'oklch(0.75 0.13 80)',
    danger:  'oklch(0.60 0.17 25)',
  },
};

function StatusDot({ tone = 'success', pulse = false, size = 8 }) {
  const c = {
    success: TOKENS.color.success,
    warn:    TOKENS.color.warn,
    danger:  TOKENS.color.danger,
    muted:   '#CBD5E1',
    primary: TOKENS.color.primary,
  }[tone];
  return (
    <span className="relative inline-flex" style={{ width: size, height: size }}>
      {pulse && (
        <span className="absolute inline-flex h-full w-full rounded-full opacity-60"
              style={{ background: c, animation: 'ja-ping 1.8s cubic-bezier(0,0,.2,1) infinite' }}/>
      )}
      <span className="relative inline-flex rounded-full" style={{ width: size, height: size, background: c }}/>
    </span>
  );
}

function Button({ children, variant = 'primary', size = 'md', className = '', ...rest }) {
  const sizes = {
    sm: 'h-8 px-3 text-[13px]',
    md: 'h-10 px-4 text-[14px]',
    lg: 'h-11 px-5 text-[14.5px]',
  };
  const base = 'inline-flex items-center justify-center gap-1.5 rounded-full font-medium transition active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2';
  const variants = {
    primary:   'text-white',
    secondary: 'bg-white text-slate-900 border border-slate-200 hover:border-slate-300',
    ghost:     'text-slate-500 hover:text-slate-900 hover:bg-slate-100',
  };
  const style = variant === 'primary' ? { background: TOKENS.color.primary } : {};
  return (
    <button className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} style={style} {...rest}>
      {children}
    </button>
  );
}

function IconBtn({ children, onClick, title, className = '' }) {
  return (
    <button onClick={onClick} title={title}
      className={`inline-flex h-9 w-9 items-center justify-center rounded-full text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition ${className}`}>
      {children}
    </button>
  );
}

// Minimal icon set — hairline strokes
const I = {
  search:  (p={}) => <svg width={p.s||16} height={p.s||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>,
  bell:    (p={}) => <svg width={p.s||16} height={p.s||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 1 1 12 0c0 4 2 5 2 7H4c0-2 2-3 2-7Z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>,
  settings:(p={}) => <svg width={p.s||16} height={p.s||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></svg>,
  check:   (p={}) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12.5 9 17 20 6"/></svg>,
  x:       (p={}) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M6 6l12 12M18 6l-12 12"/></svg>,
  arrow:   (p={}) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>,
  pin:     (p={}) => <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="10" r="3"/><path d="M12 2a8 8 0 0 1 8 8c0 5-8 12-8 12S4 15 4 10a8 8 0 0 1 8-8Z"/></svg>,
  dollar:  (p={}) => <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v18M17 7H9.5a3 3 0 0 0 0 6h5a3 3 0 1 1 0 6H6"/></svg>,
  clock:   (p={}) => <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
  sliders: (p={}) => <svg width={p.s||16} height={p.s||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/></svg>,
  bookmark:(p={}) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill={p.filled?'currentColor':'none'} stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h12v18l-6-4-6 4z"/></svg>,
  file:    (p={}) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M7 3h8l5 5v13H7z"/><path d="M14 3v6h6"/></svg>,
  skill:   (p={}) => <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="m5 12 4 4 10-10"/></svg>,
  exp:     (p={}) => <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>,
  loc:     (p={}) => <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="10" r="3"/><path d="M12 2a8 8 0 0 1 8 8c0 5-8 12-8 12S4 15 4 10a8 8 0 0 1 8-8Z"/></svg>,
  warn:    (p={}) => <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17v.01"/></svg>,
  spark:   (p={}) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></svg>,
  chev:    (p={}) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>,
  plus:    (p={}) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14"/></svg>,
};

function Logo({ size = 24 }) {
  return (
    <div className="inline-flex items-center gap-2">
      <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
        <rect width="32" height="32" rx="8" fill={TOKENS.color.primary}/>
        <path d="M9 11h14M9 16h10" stroke="white" strokeWidth="2.2" strokeLinecap="round"/>
        <circle cx="22" cy="21" r="3.5" fill="white"/>
        <path d="m20.3 21 1.3 1.3 2.3-2.7" stroke={TOKENS.color.primary} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
      <span className="font-semibold text-[15px] tracking-tight text-slate-900">Job Apply</span>
    </div>
  );
}

function Toggle({ on, onChange, size = 'md' }) {
  const w = size === 'sm' ? 32 : 40;
  const h = size === 'sm' ? 18 : 22;
  const d = h - 4;
  return (
    <button onClick={() => onChange(!on)}
      className="inline-flex items-center rounded-full transition-colors"
      style={{ width: w, height: h, background: on ? TOKENS.color.primary : '#E2E8F0', padding: 2 }}>
      <span className="rounded-full bg-white shadow transition-transform"
        style={{ width: d, height: d, transform: `translateX(${on ? w - d - 4 : 0}px)` }}/>
    </button>
  );
}

Object.assign(window, { TOKENS, StatusDot, Button, IconBtn, I, Logo, Toggle });
