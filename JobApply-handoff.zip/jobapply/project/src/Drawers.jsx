// Drawers — ReportDrawer (with Integrity & Confidence Optimizer) + ControlsSheet.

// ---------- whyRon parser ----------
function parseWhyRon(text) {
  if (!text) return [];
  const lines = text.split('\n');
  const blocks = [];
  for (const raw of lines) {
    const line = raw.replace(/\s+$/,'');
    if (!line.trim()) { blocks.push({ kind: 'gap' }); continue; }
    if (line.startsWith('# ')) { blocks.push({ kind:'h1', text: line.slice(2) }); continue; }
    if (/^—.*—$/.test(line.trim())) { blocks.push({ kind:'subtitle', text: line.trim().replace(/^—|—$/g,'') }); continue; }
    if (/^━+$/.test(line.trim())) { blocks.push({ kind:'divider' }); continue; }
    const stars = line.match(/^(★+☆*)\s+(.*)$/);
    if (stars) { blocks.push({ kind:'stars', filled: (stars[1].match(/★/g)||[]).length, total: 5, label: stars[2] }); continue; }
    if (/^    /.test(raw)) { blocks.push({ kind:'meta', text: line.trim() }); continue; }
    const num = line.match(/^(\d+)\.\s+(.*)$/);
    if (num) { blocks.push({ kind:'numbered', n: num[1], text: num[2] }); continue; }
    if (line === line.toUpperCase() && line.length > 2 && /[A-Z]/.test(line)) { blocks.push({ kind:'section-heading', text: line }); continue; }
    blocks.push({ kind:'body', text: line });
  }
  return blocks;
}

const Stars = ({ filled, total = 5 }) => (
  <span className="inline-flex gap-[2px]">
    {Array.from({length: total}).map((_, i) => (
      <span key={i} className={`text-[13px] leading-none ${i < filled ? 'text-ember-400' : 'text-paper-300'}`}>★</span>
    ))}
  </span>
);

const ReportBody = ({ blocks }) => (
  <div className="space-y-3.5 text-[14px] leading-[1.55] text-ink-700">
    {blocks.map((b, i) => {
      switch (b.kind) {
        case 'h1':       return <h2 key={i} className="display text-[24px] leading-tight text-ink-900 mt-2">{b.text}</h2>;
        case 'subtitle': return <p key={i} className="text-[13px] italic text-ink-500 -mt-1">— {b.text} —</p>;
        case 'divider':  return <div key={i} className="hair my-2"/>;
        case 'section-heading': return <h3 key={i} className="text-[11px] uppercase tracking-[0.16em] font-semibold text-ink-500 pt-2">{b.text}</h3>;
        case 'stars':    return (
          <div key={i} className="flex items-baseline gap-2.5">
            <Stars filled={b.filled} total={b.total}/>
            <span className="text-[13.5px] text-ink-800 font-medium">{b.label}</span>
          </div>
        );
        case 'meta':     return <div key={i} className="text-[12.5px] text-ink-500 pl-7 -mt-2">{b.text}</div>;
        case 'numbered': return (
          <div key={i} className="flex gap-3">
            <span className="num text-[12.5px] text-ink-400 font-mono pt-0.5 w-5 shrink-0">{b.n.padStart(2,'0')}</span>
            <span>{b.text}</span>
          </div>
        );
        case 'body':     return <p key={i}>{b.text}</p>;
        case 'gap':      return <div key={i} className="h-1"/>;
        default:         return null;
      }
    })}
  </div>
);

// ---------- Integrity & Confidence Optimizer (3-step vertical) ----------
//   Step 1: Skills + match percentage (READ-ONLY summary of where you stand)
//   Step 2: File upload zone (improve match with new evidence)
//   Step 3: Text input area (free-text context for the agent)

const SkillBar = ({ label, score, weight = 'normal' }) => (
  <div>
    <div className="flex items-baseline justify-between mb-1.5">
      <span className={`text-[13px] ${weight === 'strong' ? 'font-semibold text-ink-900' : 'text-ink-800'}`}>{label}</span>
      <span className="num text-[12.5px] text-ink-500">{score}%</span>
    </div>
    <div className="h-1.5 bg-paper-200 rounded-full overflow-hidden">
      <div className="h-full rounded-full transition-all" style={{ width: `${score}%`, background: score >= 80 ? '#1F5236' : score >= 60 ? '#2E5AAC' : '#E8552A' }}/>
    </div>
  </div>
);

const StepHeader = ({ n, title, sub, complete = false }) => (
  <div className="flex items-start gap-3 mb-4">
    <div className={`relative shrink-0 w-7 h-7 rounded-full border-2 flex items-center justify-center text-[12px] font-semibold ${complete ? 'bg-ink-900 border-ink-900 text-white' : 'bg-paper-0 border-ink-900 text-ink-900'}`}>
      {complete ? <I.Check size={13}/> : n}
    </div>
    <div className="min-w-0 flex-1 pt-0.5">
      <div className="text-[15px] font-semibold text-ink-900 leading-tight">{title}</div>
      <div className="text-[12.5px] text-ink-500 mt-0.5">{sub}</div>
    </div>
  </div>
);

const IntegrityOptimizer = ({ job, onClose }) => {
  const skills = React.useMemo(() => ([
    { label: 'Design systems',          score: 95, weight: 'strong' },
    { label: 'Figma component arch.',   score: 92, weight: 'strong' },
    { label: 'Frontend literacy (TS)',  score: 78 },
    { label: 'Public API design',       score: 58 },
    { label: 'Stakeholder facilitation',score: 71 },
  ]), [job?.id]);

  const baseScore = job?.score ?? 0;

  const [files, setFiles]   = React.useState([]);
  const [note,  setNote]    = React.useState('');
  const [boost, setBoost]   = React.useState(0);
  const [dragOver, setDragOver] = React.useState(false);

  React.useEffect(() => {
    const fileBoost = Math.min(6, files.length * 3);
    const noteBoost = Math.min(4, Math.floor(note.length / 60));
    setBoost(fileBoost + noteBoost);
  }, [files, note]);

  const newScore = Math.min(100, baseScore + boost);

  const onDrop = (e) => {
    e.preventDefault(); setDragOver(false);
    const list = Array.from(e.dataTransfer.files || []).map(f => ({ name: f.name, size: f.size }));
    setFiles(f => [...f, ...list]);
  };
  const onPick = (e) => {
    const list = Array.from(e.target.files || []).map(f => ({ name: f.name, size: f.size }));
    setFiles(f => [...f, ...list]);
  };

  return (
    <div className="anim-fade">
      {/* Headline summary */}
      <div className="rounded-xl2 border border-paper-200 bg-paper-50 p-5 mb-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[10.5px] uppercase tracking-[0.14em] font-semibold text-ember-500 mb-1.5">
              <I.Shield size={11}/>
              Integrity & Confidence Optimizer
            </div>
            <h3 className="display text-[24px] leading-tight text-ink-900">Strengthen your match before you apply.</h3>
            <p className="text-[13px] text-ink-600 mt-1.5 max-w-[42ch]">Add evidence, share context — and watch your match score and recruiter confidence climb in real time.</p>
          </div>
          <div className="text-right shrink-0">
            <div className="text-[10.5px] uppercase tracking-[0.14em] text-ink-500 mb-1">Match</div>
            <div className="flex items-baseline gap-2 justify-end">
              <span className="num display text-[40px] leading-none text-ink-900">{newScore}</span>
              <span className="text-[14px] text-ink-400">/100</span>
            </div>
            {boost > 0 && (
              <div className="text-[11.5px] text-[#1F5236] font-medium bg-[#E8F0EA] border border-[#CFE0D5] rounded-full px-2 py-0.5 mt-1.5 inline-block">
                +{boost} from your inputs
              </div>
            )}
          </div>
        </div>
      </div>

      {/* STEP 1 — Skills + match % */}
      <div className="relative pl-10 pb-8">
        <div className="absolute left-3.5 top-9 bottom-0 w-px step-line"/>
        <div className="absolute left-0 top-0">
          <StepHeader n="1" title="" sub="" complete={true}/>
        </div>
        <div className="-mt-1">
          <div className="text-[15px] font-semibold text-ink-900 leading-tight">Skills & match percentage</div>
          <div className="text-[12.5px] text-ink-500 mt-0.5 mb-4">How your profile stacks against this role.</div>
          <div className="rounded-xl2 border border-paper-200 bg-paper-0 p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
              {skills.map(s => <SkillBar key={s.label} {...s}/>)}
            </div>
            <div className="hair my-5"/>
            <div className="flex items-center gap-2 text-[12.5px] text-ink-600">
              <I.Sparkle size={13} className="text-ember-500"/>
              Two skills below 80% are pulling your score down. Steps 2 & 3 can lift them.
            </div>
          </div>
        </div>
      </div>

      {/* STEP 2 — File upload */}
      <div className="relative pl-10 pb-8">
        <div className="absolute left-3.5 top-9 bottom-0 w-px step-line"/>
        <div className="absolute left-0 top-0">
          <StepHeader n="2" title="" sub="" complete={files.length > 0}/>
        </div>
        <div className="-mt-1">
          <div className="text-[15px] font-semibold text-ink-900 leading-tight">Upload supporting evidence</div>
          <div className="text-[12.5px] text-ink-500 mt-0.5 mb-4">Case studies, certificates, code samples, or a tailored CV. PDF, MD, DOCX, PNG up to 10 MB.</div>
          <label
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={onDrop}
            className={`relative block border-2 border-dashed rounded-xl2 p-7 text-center cursor-pointer transition-colors ${dragOver ? 'border-ember-400 bg-ember-50/40' : 'border-paper-300 bg-paper-50 hover:bg-paper-100/60 hover:border-paper-400'}`}
          >
            <input type="file" multiple onChange={onPick} className="absolute inset-0 opacity-0 cursor-pointer"/>
            <div className="w-10 h-10 mx-auto rounded-full bg-paper-0 border border-paper-300 flex items-center justify-center text-ink-700 shadow-card mb-2.5">
              <I.Upload size={16}/>
            </div>
            <div className="text-[13.5px] text-ink-900 font-medium">Drop files or <span className="text-ember-500 underline-offset-2 hover:underline">browse</span></div>
            <div className="text-[12px] text-ink-500 mt-1">+3 points per relevant attachment, up to +6.</div>
          </label>
          {files.length > 0 && (
            <ul className="mt-3 space-y-1.5">
              {files.map((f, i) => (
                <li key={i} className="flex items-center justify-between gap-3 px-3.5 py-2 bg-paper-0 border border-paper-200 rounded-lg text-[12.5px]">
                  <div className="flex items-center gap-2 min-w-0">
                    <I.Doc size={13} className="text-ink-500 shrink-0"/>
                    <span className="truncate text-ink-800">{f.name}</span>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="num text-[11px] text-ink-400">{(f.size/1024).toFixed(0)} KB</span>
                    <button onClick={() => setFiles(files.filter((_,j) => j!==i))} className="text-ink-400 hover:text-ember-500"><I.Close size={12}/></button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* STEP 3 — Text input */}
      <div className="relative pl-10">
        <div className="absolute left-0 top-0">
          <StepHeader n="3" title="" sub="" complete={note.length >= 60}/>
        </div>
        <div className="-mt-1">
          <div className="text-[15px] font-semibold text-ink-900 leading-tight">Add context for the agent</div>
          <div className="text-[12.5px] text-ink-500 mt-0.5 mb-4">Anything your CV doesn't capture. Tone, motivation, gaps, deal-breakers — write it like a note.</div>
          <div className="rounded-xl2 border border-paper-200 bg-paper-0 focus-within:border-ink-700 transition-colors">
            <textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="I've been quietly studying public-API ergonomics with the Stripe SDK team for the last six months — happy to walk through the work if useful…"
              rows={5}
              className="w-full resize-none bg-transparent p-4 text-[13.5px] text-ink-900 placeholder:text-ink-400 outline-none leading-relaxed"
            />
            <div className="flex items-center justify-between px-4 py-2 border-t border-paper-200">
              <div className="text-[11.5px] text-ink-500 num">{note.length} chars · +1 every 60 (cap +4)</div>
              <Pill tone={note.length >= 60 ? 'forest' : 'default'}>
                {note.length >= 60 ? <I.Check size={11}/> : <I.Sparkle size={11}/>}
                {note.length >= 60 ? 'Counted' : 'Keep going'}
              </Pill>
            </div>
          </div>
        </div>
      </div>

      {/* Footer actions */}
      <div className="mt-7 pt-5 border-t border-paper-200 flex items-center justify-between gap-3">
        <div className="text-[12.5px] text-ink-500">
          Final match {' '}
          <span className="num text-ink-900 font-semibold">{newScore}</span>
          {boost > 0 && <span className="text-[#1F5236] font-medium"> · +{boost} earned</span>}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost"   size="md" onClick={onClose}>Save & close</Button>
          <Button variant="accent"  size="md" icon={<I.Bolt size={14}/>}>Apply with this</Button>
        </div>
      </div>
    </div>
  );
};

// ---------- ReportDrawer ----------
const ReportDrawer = ({ job, mode, onClose, onSwitchMode }) => {
  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  if (!job) return null;
  const blocks = parseWhyRon(job.whyRon);

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-ink-900/30 backdrop-blur-[2px] anim-fade" onClick={onClose}/>
      <aside className="absolute right-0 top-0 bottom-0 w-full sm:w-[640px] bg-paper-50 border-l border-paper-300 shadow-pop flex flex-col anim-drawer">
        {/* Header */}
        <div className="px-7 pt-6 pb-4 border-b border-paper-200 bg-paper-0">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="text-[10.5px] uppercase tracking-[0.14em] text-ink-500 font-medium">{mode === 'integrity' ? 'Pre-flight' : 'Analysis report'}</div>
              <h2 className="display text-[26px] leading-tight text-ink-900 mt-1 truncate">{job.title}</h2>
              <div className="text-[13px] text-ink-600 mt-0.5">
                <span className="font-medium text-ink-800">{job.company}</span>
                <span className="text-ink-300 mx-1.5">·</span>{job.location}
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <div className="bg-paper-0 border border-paper-200 rounded-full pl-3 pr-1.5 py-1 flex items-center gap-2">
                <ScoreRing score={job.score} size={28} stroke={2.5} showLabel={false}/>
                <span className="num text-[13px] font-semibold text-ink-900">{job.score}</span>
                <span className="text-[11px] text-ink-400">/100</span>
              </div>
              <IconBtn onClick={onClose} title="Close (Esc)"><I.Close size={14}/></IconBtn>
            </div>
          </div>
          {/* Mode tabs */}
          <div className="mt-4 inline-flex p-1 rounded-full bg-paper-100 border border-paper-200">
            {[
              { id:'report',    label:'Recruiter brief', icon:<I.Doc size={12}/> },
              { id:'integrity', label:'Confidence Optimizer', icon:<I.Shield size={12}/> },
            ].map(t => (
              <button
                key={t.id}
                onClick={() => onSwitchMode(t.id)}
                className={`inline-flex items-center gap-1.5 h-8 px-3.5 rounded-full text-[12.5px] font-medium transition-colors ${mode === t.id ? 'bg-paper-0 text-ink-900 shadow-card' : 'text-ink-600 hover:text-ink-900'}`}
              >
                {t.icon}
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto drawer-scroll px-7 py-6">
          {mode === 'integrity' ? (
            <IntegrityOptimizer job={job} onClose={onClose}/>
          ) : blocks.length ? (
            <ReportBody blocks={blocks}/>
          ) : (
            <div className="text-center py-12">
              <div className="w-12 h-12 rounded-full bg-paper-100 border border-paper-200 mx-auto flex items-center justify-center text-ink-500 mb-3">
                <I.Doc size={20}/>
              </div>
              <div className="text-[14px] text-ink-700 font-medium">No analysis report available for this job.</div>
              <div className="text-[12.5px] text-ink-500 mt-1.5 max-w-[40ch] mx-auto">Run the analysis pipeline on this URL to generate a full recruiter brief.</div>
              <Button variant="primary" size="md" className="mt-5" icon={<I.Bolt size={14}/>}>Run analysis pipeline</Button>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
};

// ---------- ControlsSheet ----------
const Slider = ({ value, min, max, step = 1, onChange, format }) => {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="num display text-[26px] leading-none text-ink-900">{format ? format(value) : value}</span>
        <span className="text-[11px] text-ink-400 num">{min} – {max}</span>
      </div>
      <input
        type="range"
        min={min} max={max} step={step}
        value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full appearance-none h-1.5 rounded-full cursor-pointer"
        style={{ background: `linear-gradient(to right, #0E0E0C 0%, #0E0E0C ${pct}%, #E2DED1 ${pct}%, #E2DED1 100%)` }}
      />
    </div>
  );
};

const ControlsSheet = ({ open, settings, setSettings, onClose }) => {
  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    if (open) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  const update = (k, v) => setSettings(s => ({ ...s, [k]: v }));
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-ink-900/30 backdrop-blur-[2px] anim-fade" onClick={onClose}/>
      <aside className="absolute right-0 top-0 bottom-0 w-full sm:w-[460px] bg-paper-50 border-l border-paper-300 shadow-pop flex flex-col anim-drawer">
        <div className="flex items-center justify-between px-6 py-5 border-b border-paper-200 bg-paper-0">
          <div>
            <div className="text-[10.5px] uppercase tracking-[0.14em] text-ink-500 font-medium">Preferences</div>
            <h2 className="display text-[24px] leading-tight text-ink-900 mt-0.5">Automation</h2>
          </div>
          <IconBtn onClick={onClose}><I.Close size={14}/></IconBtn>
        </div>
        <div className="flex-1 overflow-y-auto drawer-scroll px-6 py-5 space-y-7">
          <div className="bg-paper-0 border border-paper-200 rounded-xl2 p-5">
            <Toggle
              checked={settings.autoApply}
              onChange={v => update('autoApply', v)}
              label="Auto-Apply"
              sub="Submit applications automatically for strong matches."
            />
          </div>

          <div className="bg-paper-0 border border-paper-200 rounded-xl2 p-5">
            <SectionLabel>Daily limit</SectionLabel>
            <div className="mt-3">
              <Slider value={settings.dailyLimit} min={5} max={50} onChange={v => update('dailyLimit', v)}/>
              <div className="flex items-center justify-between mt-2 text-[12px] text-ink-500">
                <span><span className="num text-ink-700 font-medium">{settings.dailyUsed}</span> of <span className="num text-ink-700 font-medium">{settings.dailyLimit}</span> used</span>
                <div className="h-1 w-24 bg-paper-200 rounded-full overflow-hidden">
                  <div className="h-full bg-ink-900 rounded-full" style={{ width: `${(settings.dailyUsed/settings.dailyLimit)*100}%` }}/>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-paper-0 border border-paper-200 rounded-xl2 p-5">
            <SectionLabel>Minimum match score</SectionLabel>
            <div className="mt-3">
              <Slider value={settings.threshold} min={50} max={100} onChange={v => update('threshold', v)} format={v => `${v}+`}/>
              <div className="text-[12px] text-ink-500 mt-2">Below this, matches wait for your review.</div>
            </div>
          </div>

          <div className="bg-paper-0 border border-paper-200 rounded-xl2 p-5 divide-y divide-paper-200">
            <div className="pb-3"><Toggle checked={settings.tailor}      onChange={v => update('tailor',     v)} label="Tailor cover letter to each job"      sub="Content Strategist drafts a custom letter per role."/></div>
            <div className="py-3"><Toggle  checked={settings.skipDup}     onChange={v => update('skipDup',    v)} label="Skip companies I already applied to"  sub="Avoid duplicate submissions to the same company within 90 days."/></div>
            <div className="pt-3"><Toggle  checked={settings.pauseOnRej}  onChange={v => update('pauseOnRej', v)} label="Pause if I get rejected today"        sub="Holds Auto-Apply for 24 hours after a rejection."/></div>
          </div>
        </div>
        <div className="px-6 py-4 border-t border-paper-200 bg-paper-0 flex items-center justify-between">
          <span className="text-[12px] text-ink-500">Changes save instantly.</span>
          <Button variant="primary" size="md" onClick={onClose}>Done</Button>
        </div>
      </aside>
    </div>
  );
};

Object.assign(window, { ReportDrawer, ControlsSheet, IntegrityOptimizer, parseWhyRon });
