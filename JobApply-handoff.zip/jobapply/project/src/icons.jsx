// Hand-tuned inline SVG icons. 1.5 stroke, 20px box.
const I = {
  Spark: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M10 2.5l1.6 4.4 4.4 1.6-4.4 1.6L10 14.5l-1.6-4.4L4 8.5l4.4-1.6L10 2.5z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
    </svg>
  ),
  Bolt: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M11 2L4 11h5l-1 7 7-9h-5l1-7z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
    </svg>
  ),
  Map: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M10 17s5-4.5 5-9a5 5 0 10-10 0c0 4.5 5 9 5 9z" stroke="currentColor" strokeWidth="1.4"/>
      <circle cx="10" cy="8" r="1.8" stroke="currentColor" strokeWidth="1.4"/>
    </svg>
  ),
  Shield: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M10 2l6 2v5c0 4-3 6.5-6 8-3-1.5-6-4-6-8V4l6-2z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
    </svg>
  ),
  Bookmark: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill={p.filled? 'currentColor':'none'} {...p}>
      <path d="M5 3h10v15l-5-3-5 3V3z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
    </svg>
  ),
  Arrow: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||14} height={p.size||14} fill="none" {...p}>
      <path d="M4 10h12M11 5l5 5-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Close: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M5 5l10 10M15 5L5 15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  Doc: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M5 2h7l3 3v13H5V2z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
      <path d="M12 2v3h3M7 10h6M7 13h6M7 7h3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  Upload: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M10 13V3M6 7l4-4 4 4M3 14v2a1 1 0 001 1h12a1 1 0 001-1v-2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Check: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M4 10.5L8 14l8-8" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Filter: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M3 5h14M6 10h8M9 15h2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  Search: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <circle cx="9" cy="9" r="5" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M13 13l4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  // Settings — solid filled gear
  Settings: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="currentColor" {...p}>
      <path fillRule="evenodd" clipRule="evenodd" d="M11.49 2.17a1.5 1.5 0 00-2.98 0l-.16 1.13a6 6 0 00-1.5.62l-.91-.68a1.5 1.5 0 00-2.1 2.1l.68.91a6 6 0 00-.62 1.5l-1.13.16a1.5 1.5 0 000 2.98l1.13.16a6 6 0 00.62 1.5l-.68.91a1.5 1.5 0 002.1 2.1l.91-.68a6 6 0 001.5.62l.16 1.13a1.5 1.5 0 002.98 0l.16-1.13a6 6 0 001.5-.62l.91.68a1.5 1.5 0 002.1-2.1l-.68-.91a6 6 0 00.62-1.5l1.13-.16a1.5 1.5 0 000-2.98l-1.13-.16a6 6 0 00-.62-1.5l.68-.91a1.5 1.5 0 00-2.1-2.1l-.91.68a6 6 0 00-1.5-.62l-.16-1.13zM10 13a3 3 0 100-6 3 3 0 000 6z"/>
    </svg>
  ),
  // Bell — solid with notch
  Bell: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="currentColor" {...p}>
      <path d="M10 2a4 4 0 00-4 4v3.2c0 .5-.2 1-.6 1.4L4 12h12l-1.4-1.4a2 2 0 01-.6-1.4V6a4 4 0 00-4-4z"/>
      <path d="M8 15a2 2 0 004 0H8z"/>
    </svg>
  ),
  Switch: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M3 7h12l-3-3M17 13H5l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Plus: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M10 4v12M4 10h12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  Sparkle: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M6 3v3M4.5 4.5h3M14 12v4M12 14h4M10 5l1.6 3.4L15 10l-3.4 1.6L10 15l-1.6-3.4L5 10l3.4-1.6L10 5z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" strokeLinecap="round"/>
    </svg>
  ),
  Refresh: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M4 10a6 6 0 0110.5-4M16 10a6 6 0 01-10.5 4M14 3v3.5h-3.5M6 17v-3.5h3.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  User: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <circle cx="10" cy="7" r="3" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M3 17c1.2-3 4-4.5 7-4.5s5.8 1.5 7 4.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  Logout: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M9 4H5a1 1 0 00-1 1v10a1 1 0 001 1h4M13 7l3 3-3 3M16 10H8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Briefcase: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <rect x="3" y="6" width="14" height="11" rx="2" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M7 6V4.5A1.5 1.5 0 018.5 3h3A1.5 1.5 0 0113 4.5V6M3 11h14" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  Robot: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <rect x="4" y="6" width="12" height="10" rx="2" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M10 3v3M8 11v1M12 11v1" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <circle cx="10" cy="3" r=".75" fill="currentColor"/>
    </svg>
  ),
  Lock: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <rect x="4" y="9" width="12" height="8" rx="2" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M7 9V7a3 3 0 016 0v2" stroke="currentColor" strokeWidth="1.4"/>
    </svg>
  ),
  Help: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <circle cx="10" cy="10" r="7" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M8 8a2 2 0 014 0c0 1.2-1 1.6-1.5 2-.4.3-.5.6-.5 1M10 14h.01" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  Mail: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <rect x="3" y="5" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M3 6.5l7 5 7-5" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
    </svg>
  ),
  Eye: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} fill="none" {...p}>
      <path d="M2 10s3-5 8-5 8 5 8 5-3 5-8 5-8-5-8-5z" stroke="currentColor" strokeWidth="1.4"/>
      <circle cx="10" cy="10" r="2" stroke="currentColor" strokeWidth="1.4"/>
    </svg>
  ),
  Google: (p) => (
    <svg viewBox="0 0 20 20" width={p.size||16} height={p.size||16} {...p}>
      <path fill="#4285F4" d="M19 10.2c0-.6-.05-1.2-.15-1.7H10v3.4h5.05a4.3 4.3 0 01-1.85 2.85v2.4h3a9 9 0 002.8-6.95z"/>
      <path fill="#34A853" d="M10 19c2.5 0 4.6-.83 6.15-2.25l-3-2.4c-.83.55-1.9.9-3.15.9-2.45 0-4.5-1.6-5.25-3.85h-3.1v2.45A9 9 0 0010 19z"/>
      <path fill="#FBBC04" d="M4.75 11.4a5.4 5.4 0 010-3.45V5.5h-3.1a9 9 0 000 8.45l3.1-2.55z"/>
      <path fill="#EA4335" d="M10 4.6c1.4 0 2.65.5 3.65 1.45l2.65-2.65A9 9 0 001.65 5.5l3.1 2.45C5.5 5.7 7.55 4.6 10 4.6z"/>
    </svg>
  ),
};

window.I = I;
