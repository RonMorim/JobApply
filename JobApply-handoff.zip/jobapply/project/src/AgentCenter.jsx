// AgentStatusCenter — live state of the 4-stage analysis pipeline.

const AGENT_STATE_META = {
  active: { tone: 'success', label: 'Active',  pulse: true,  bg: 'bg-[#E8F0EA]', text: 'text-[#1F5236]', border: 'border-[#CFE0D5]' },
  idle:   { tone: 'muted',   label: 'Idle',    pulse: false, bg: 'bg-paper-100', text: 'text-ink-600',   border: 'border-paper-300' },
  queued: { tone: 'primary', label: 'Queued',  pulse: false, bg: 'bg-[#E8EEFA]', text: 'text-[#2E5AAC]', border: 'border-[#CFDBF1]' },
  error:  { tone: 'danger',  label: 'Error',   pulse: true,  bg: 'bg-ember-50',  text: 'text-ember-600', border: 'border-ember-100' },
  paused: { tone: 'warn',    label: 'Paused',  pulse: false, bg: 'bg-[#FAF1DD]', text: 'text-[#8A5A00]', border: 'border-[#EBDBB0]' },
};

const AgentCard = ({ agent }) => {
  const m = AGENT_STATE_META[agent.state] || AGENT_STATE_META.idle;
  const initial = agent.name[0];
  const taskLine = agent.state === 'active' ? agent.current_task
    : agent.state === 'queued' ? agent.queue_msg
    : agent.state === 'error'  ? agent.error_msg
    : agent.state === 'paused' ? 'Paused by you'
    : 'Standing by';
  return (
    <div className="bg-paper-0 border border-paper-200 rounded-xl2 p-4 shadow-card flex flex-col gap-3 hover:border-paper-300 transition-colors">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-full bg-ember-50 border border-ember-100 text-ember-600 flex items-center justify-center font-semibold text-[14px]">{initial}</div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <div className="text-[14px] font-semibold text-ink-900 truncate">{agent.name}</div>
            <span className="text-[11px] text-ink-400 font-mono">#{agent.id}</span>
          </div>
          <div className="text-[12px] text-ink-500 truncate">{agent.role}</div>
        </div>
        <span className={`inline-flex items-center gap-1.5 h-6 px-2 rounded-full text-[11.5px] font-medium border ${m.bg} ${m.text} ${m.border}`}>
          <StatusDot tone={m.tone} pulse={m.pulse}/>
          {m.label}
        </span>
      </div>
      <div className="text-[12.5px] text-ink-700 leading-snug min-h-[34px]">{taskLine}</div>
      <div className="flex items-end justify-between pt-2 border-t border-paper-200">
        <div className="flex gap-5">
          <div>
            <div className="text-[10.5px] uppercase tracking-wider text-ink-400">Today</div>
            <div className="num text-[16px] font-semibold text-ink-900">{agent.stats.today.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-[10.5px] uppercase tracking-wider text-ink-400">Queue</div>
            <div className="num text-[16px] font-semibold text-ink-900">{agent.stats.queue}</div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <div className="text-[10.5px] uppercase tracking-wider text-ink-400">Throughput</div>
          <MiniBars data={agent.stats.spark} color="#0E0E0C"/>
        </div>
      </div>
    </div>
  );
};

const PipelineFlow = ({ agents }) => (
  <div className="flex items-center flex-wrap gap-x-2 gap-y-2 px-4 py-3 rounded-xl2 bg-paper-50 border border-paper-200">
    {agents.map((a, i) => {
      const m = AGENT_STATE_META[a.state] || AGENT_STATE_META.idle;
      return (
        <React.Fragment key={a.id}>
          <span className="inline-flex items-center gap-1.5 text-[12.5px] text-ink-800">
            <StatusDot tone={m.tone} pulse={m.pulse}/>
            <span className="font-medium">{a.name}</span>
          </span>
          {i < agents.length - 1 && <span className="text-ink-300 text-[12px]">→</span>}
        </React.Fragment>
      );
    })}
  </div>
);

const AgentStatusCenter = ({ agents = [], onConfigure, error = null }) => {
  const [url, setUrl] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [success, setSuccess] = React.useState('');
  const running = agents.some(a => a.state === 'active');

  const submit = async (e) => {
    e.preventDefault();
    if (!url) return;
    setLoading(true); setSuccess('');
    setTimeout(() => {
      setLoading(false);
      setSuccess('Pipeline started · job queued for analysis.');
      setUrl('');
    }, 900);
  };

  return (
    <section id="agent-center" className="mt-12">
      <SectionHead
        kicker="Agent Status Center"
        title="Live state of the 4-stage analysis pipeline"
        sub="Four agents scan, score, tailor, and quality-check every role before it reaches you."
        right={
          <div className="flex items-center gap-2">
            <Pill tone={running ? 'forest' : 'default'} icon={<StatusDot tone={running ? 'success' : 'muted'} pulse={running}/>}>
              {running ? 'Pipeline running' : 'All systems nominal'}
            </Pill>
            <Button variant="secondary" size="sm" onClick={onConfigure} icon={<I.Settings size={14}/>}>Configure</Button>
          </div>
        }
      />

      {error && (
        <div className="mb-4 p-3.5 rounded-xl2 bg-ember-50 border border-ember-100 flex items-center justify-between">
          <div className="text-[13px] text-ember-600">Agent status unavailable — {error}</div>
          <Button variant="danger" size="sm" icon={<I.Refresh size={14}/>}>Retry</Button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {agents.map(a => <AgentCard key={a.id} agent={a}/>)}
      </div>

      <div className="mt-4">
        <PipelineFlow agents={agents}/>
      </div>

      <div className="mt-4 bg-paper-0 border border-paper-200 rounded-xl2 shadow-card p-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-[14px] font-semibold text-ink-900">Analyze a job URL</div>
            <div className="text-[12.5px] text-ink-500">Run the full 4-agent workflow on demand.</div>
          </div>
          {success && <Pill tone="forest" icon={<I.Check size={12}/>}>{success}</Pill>}
        </div>
        <form onSubmit={submit} className="flex gap-2">
          <div className="flex-1 flex items-center gap-2 px-3 h-11 rounded-full border border-paper-300 bg-paper-50 focus-within:border-ink-700 focus-within:bg-paper-0">
            <I.Map size={16} className="text-ink-400"/>
            <input
              type="url"
              value={url}
              onChange={e => setUrl(e.target.value)}
              placeholder="https://jobs.lever.co/company/job-id"
              className="flex-1 bg-transparent text-[13.5px] text-ink-900 placeholder:text-ink-400 outline-none"
            />
          </div>
          <Button variant="accent" size="lg" type="submit" disabled={loading} icon={<I.Bolt size={14}/>}>
            {loading ? 'Starting…' : 'Run'}
          </Button>
        </form>
        {success && (
          <div className="text-[12px] text-ink-500 mt-2.5 pl-1">Agent cards above update every 5 s as the pipeline progresses.</div>
        )}
      </div>
    </section>
  );
};

Object.assign(window, { AgentStatusCenter, AgentCard, PipelineFlow, AGENT_STATE_META });
