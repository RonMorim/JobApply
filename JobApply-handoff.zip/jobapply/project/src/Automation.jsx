// Automation — dedicated full page (replaces the cramped overview card + sheet).

const Slider = ({ value, min, max, step = 1, onChange, format }) => {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="num display text-[28px] leading-none text-ink-900 font-semibold">{format ? format(value) : value}</span>
        <span className="text-[11px] text-ink-400 num">{min} – {max}</span>
      </div>
      <input
        type="range"
        min={min} max={max} step={step}
        value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full appearance-none h-1.5 rounded-full cursor-pointer"
        style={{ background: `linear-gradient(to right, #2563EB 0%, #2563EB ${pct}%, #E5E7EB ${pct}%, #E5E7EB 100%)` }}
      />
    </div>
  );
};

const AutomationPage = ({ settings, setSettings }) => {
  const update = (k, v) => setSettings(s => ({ ...s, [k]: v }));
  const usedPct = Math.round((settings.dailyUsed / settings.dailyLimit) * 100);

  return (
    <div className="anim-fade space-y-8">
      <SectionHead
        kicker="Settings"
        title="Automation."
        sub="Tell your agents how aggressive to be. Changes save instantly."
        right={
          <Pill tone={settings.autoApply ? 'success' : 'default'} icon={<StatusDot tone={settings.autoApply ? 'success' : 'muted'} pulse={settings.autoApply}/>}>
            {settings.autoApply ? 'Auto-Apply running' : 'Auto-Apply paused'}
          </Pill>
        }
      />

      {/* Master switch */}
      <Card className="p-6">
        <div className="flex items-start justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${settings.autoApply ? 'bg-brand-600 text-white' : 'bg-paper-100 text-ink-500'}`}>
              <I.Robot size={20}/>
            </div>
            <div>
              <div className="text-[16px] font-semibold text-ink-900">Auto-Apply</div>
              <div className="text-[13px] text-ink-600 mt-1 max-w-[52ch]">Submit applications automatically for strong matches. You can review, pause, or override at any time.</div>
            </div>
          </div>
          <Toggle checked={settings.autoApply} onChange={v => update('autoApply', v)}/>
        </div>
      </Card>

      {/* Limits row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <SectionLabel>Daily limit</SectionLabel>
            <Pill tone={usedPct >= 90 ? 'warn' : 'default'}>{settings.dailyUsed}/{settings.dailyLimit} used</Pill>
          </div>
          <div className="mt-4">
            <Slider value={settings.dailyLimit} min={5} max={50} onChange={v => update('dailyLimit', v)}/>
          </div>
          <div className="h-1.5 bg-paper-200 rounded-full overflow-hidden mt-4">
            <div className="h-full bg-brand-600 rounded-full" style={{ width:`${usedPct}%` }}/>
          </div>
          <div className="text-[12px] text-ink-500 mt-3">Caps how many applications go out per day across all matches.</div>
        </Card>

        <Card className="p-6">
          <SectionLabel>Minimum match score</SectionLabel>
          <div className="mt-4">
            <Slider value={settings.threshold} min={50} max={100} onChange={v => update('threshold', v)} format={v => `${v}+`}/>
          </div>
          <div className="flex items-center gap-2 mt-4">
            <div className="flex-1 h-1.5 bg-paper-200 rounded-full overflow-hidden">
              <div className="h-full rounded-full" style={{ width:`${settings.threshold}%`, background:'linear-gradient(to right, #EAB308, #2563EB, #10B981)' }}/>
            </div>
          </div>
          <div className="text-[12px] text-ink-500 mt-3">Below this, matches wait for your manual review.</div>
        </Card>
      </div>

      {/* Behavior rules */}
      <div>
        <SectionLabel className="mb-3">Behavior rules</SectionLabel>
        <Card className="divide-y divide-paper-200">
          {[
            { k:'tailor',     l:'Tailor cover letter to each job',     s:'The Content Strategist drafts a custom letter per role.' },
            { k:'skipDup',    l:'Skip companies I already applied to', s:'Avoid duplicates within a 90-day window.' },
            { k:'pauseOnRej', l:'Pause if I get rejected today',       s:'Hold Auto-Apply for 24 hours after a rejection.' },
            { k:'approveLow', l:'Ask before applying below threshold', s:'Send borderline matches to your inbox first.' },
          ].map(r => (
            <div key={r.k} className="px-6 py-4">
              <Toggle checked={settings[r.k]} onChange={v => update(r.k, v)} label={r.l} sub={r.s}/>
            </div>
          ))}
        </Card>
      </div>

      {/* Salary target */}
      <div>
        <SectionLabel className="mb-3">Compensation</SectionLabel>
        <Card className="p-6">
          <div className="flex items-baseline justify-between mb-2">
            <span className="text-[13.5px] font-medium text-ink-900">Salary target</span>
            <span className="num text-[13px] text-ink-500">${(settings.salaryTarget/1000).toFixed(0)}k</span>
          </div>
          <Slider value={settings.salaryTarget} min={50000} max={300000} step={5000} onChange={v => update('salaryTarget', v)} format={v => `$${(v/1000).toFixed(0)}k`}/>
          <div className="text-[12px] text-ink-500 mt-3">Used to weight match scoring. Roles below 80% of this are flagged.</div>
        </Card>
      </div>

      <div className="text-center text-[12px] text-ink-400">All changes are saved automatically.</div>
    </div>
  );
};

Object.assign(window, { AutomationPage });
