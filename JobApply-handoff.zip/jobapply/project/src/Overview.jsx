// Overview tab — simplified hero, separated sub-sections.

const KpiCard = ({ label, value, sub, trend, tone = 'brand', icon }) => {
  const toneMap = {
    brand:   { bg:'bg-brand-50',  text:'text-brand-600', border:'border-brand-100' },
    success: { bg:'bg-ok-50',     text:'text-ok-600',    border:'border-ok-100'    },
    warn:    { bg:'bg-warn-50',   text:'text-warn-700',  border:'border-warn-200'  },
    muted:   { bg:'bg-paper-100', text:'text-ink-700',   border:'border-paper-200' },
  }[tone];
  return (
    <div className="bg-paper-0 border border-paper-200 rounded-2xl p-5 shadow-card hover:border-paper-300 hover:shadow-pop transition-all">
      <div className="flex items-center justify-between">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center border ${toneMap.bg} ${toneMap.text} ${toneMap.border}`}>{icon}</div>
        {trend && <span className="text-[11.5px] text-ok-700 font-medium bg-ok-50 border border-ok-100 rounded-full px-2 py-0.5">{trend}</span>}
      </div>
      <div className="mt-4">
        <div className="num display text-[34px] leading-none text-ink-900 font-semibold">{value}</div>
        <div className="text-[12.5px] uppercase tracking-[0.1em] text-ink-500 font-semibold mt-2.5">{label}</div>
        <div className="text-[12.5px] text-ink-500 mt-1 leading-snug">{sub}</div>
      </div>
    </div>
  );
};

const AgentPulse = ({ agent }) => {
  const m = AGENT_STATE_META[agent.state];
  const taskLine = agent.state === 'active' ? agent.current_task
    : agent.state === 'queued' ? agent.queue_msg
    : agent.state === 'error'  ? agent.error_msg
    : 'Standing by';
  return (
    <div className="flex items-center gap-3 py-2.5">
      <div className="w-8 h-8 shrink-0 rounded-lg bg-brand-50 border border-brand-100 text-brand-600 flex items-center justify-center font-semibold text-[12px]">{agent.name[0]}</div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-[13px] font-medium text-ink-900">{agent.name}</span>
          <StatusDot tone={m.tone} pulse={m.pulse} size={6}/>
        </div>
        <div className="text-[12px] text-ink-500 truncate">{taskLine}</div>
      </div>
      <div className="text-[11px] text-ink-400 num">{agent.stats.today.toLocaleString()}</div>
    </div>
  );
};

const MiniMatchRow = ({ job, onReview }) => (
  <button onClick={() => onReview(job)} className="w-full text-left flex items-center gap-3 py-3 px-3 -mx-3 rounded-xl hover:bg-paper-50 transition-colors group">
    <ScoreRing score={job.score} size={42} stroke={3.5} showLabel={false}/>
    <div className="min-w-0 flex-1">
      <div className="flex items-center gap-2">
        <div className="text-[13.5px] font-medium text-ink-900 truncate">{job.title}</div>
        {job.isNew && <span className="w-1.5 h-1.5 rounded-full bg-brand-600"/>}
      </div>
      <div className="text-[12px] text-ink-500 truncate">{job.company} · {job.location} · {job.postedAt}</div>
    </div>
    <span className="num text-[13px] font-semibold text-ink-900">{job.score}</span>
    <I.Arrow size={14} className="text-ink-300 group-hover:text-ink-900 transition-colors"/>
  </button>
);

const Overview = ({ jobs, apps, agents, settings, loading, onTab, onAdjust, onReview }) => {
  const newCount     = jobs.filter(j => j.isNew).length;
  const savedCount   = jobs.filter(j => j.saved).length;
  const activeApps   = apps.filter(a => a.stage !== 'rejected').length;
  const interviewed  = apps.filter(a => a.stage === 'interview' || a.stage === 'offer').length;
  const responded    = apps.filter(a => ['viewed','screening','interview','offer'].includes(a.stage)).length;
  const responseRate = apps.length ? Math.round((responded/apps.length) * 100) : 0;
  const top3         = [...jobs].sort((a,b) => b.score - a.score).slice(0,3);
  const usedPct      = Math.round((settings.dailyUsed/settings.dailyLimit)*100);

  return (
    <div className="anim-fade space-y-12">
      {/* === HERO — focused, single message === */}
      <section className="rounded-2xl bg-gradient-to-br from-brand-600 via-brand-700 to-brand-800 text-white p-8 lg:p-10 relative overflow-hidden">
        <div className="absolute inset-0 opacity-30" style={{
          backgroundImage:'radial-gradient(circle at 100% 0%, rgba(250,204,21,.4), transparent 50%), radial-gradient(circle at 0% 100%, rgba(16,185,129,.3), transparent 50%)'
        }}/>
        <div className="relative grid grid-cols-1 lg:grid-cols-3 gap-8 items-end">
          <div className="lg:col-span-2">
            <div className="text-[12px] uppercase tracking-[0.14em] font-semibold opacity-80">{new Date().toLocaleDateString(undefined, { weekday:'long', month:'long', day:'numeric' })}</div>
            <h1 className="display text-[44px] lg:text-[52px] leading-[1.05] mt-2 font-semibold">Good morning, Alex.</h1>
            <p className="text-[16px] opacity-90 mt-3 max-w-[52ch]">{newCount} new matches landed overnight. Your agents are running clean — review when you're ready.</p>
            <div className="flex flex-wrap gap-2 mt-6">
              <Button variant="secondary" size="lg" onClick={() => onTab('matches')} icon={<I.Spark size={14}/>}>Review {newCount} new matches</Button>
              <button onClick={onAdjust} className="h-11 px-5 rounded-full bg-white/10 hover:bg-white/15 backdrop-blur-sm border border-white/15 text-[14px] font-medium transition-colors inline-flex items-center gap-2">
                <I.Robot size={14}/> Tune automation
              </button>
            </div>
          </div>
          {/* Today usage glance */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/15 rounded-2xl p-5">
            <div className="flex items-center justify-between">
              <div className="text-[11px] uppercase tracking-[0.14em] font-semibold opacity-80">Today's auto-apply</div>
              <Pill tone="ink" className="!bg-white/15 !text-white !border-white/20">{settings.autoApply ? 'On' : 'Off'}</Pill>
            </div>
            <div className="num display text-[36px] font-semibold mt-3 leading-none">{settings.dailyUsed}<span className="opacity-60 text-[20px]"> / {settings.dailyLimit}</span></div>
            <div className="text-[12px] opacity-80 mt-1">applications sent</div>
            <div className="h-1.5 bg-white/15 rounded-full overflow-hidden mt-3">
              <div className="h-full bg-warn-400 rounded-full" style={{ width:`${usedPct}%` }}/>
            </div>
            <div className="text-[11.5px] opacity-80 mt-3 flex items-center gap-1.5">
              <I.Refresh size={11}/> Next run in <span className="num">12m 40s</span>
            </div>
          </div>
        </div>
      </section>

      {/* === SECTION 1: Today at a glance === */}
      <section>
        <SectionHead
          kicker="At a glance"
          title="Today's pipeline."
          sub="The numbers worth seeing first."
          right={<Button variant="ghost" size="sm" onClick={() => onTab('apps')} iconRight={<I.Arrow size={12}/>}>Open tracker</Button>}
        />
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          <KpiCard tone="brand"   icon={<I.Spark size={16}/>}    label="New matches"   value={newCount}        sub="Ranked by the Matcher" trend="+6 vs yesterday"/>
          <KpiCard tone="muted"   icon={<I.Doc size={16}/>}      label="Active apps"   value={activeApps}      sub="In review, screening, or interview"/>
          <KpiCard tone="success" icon={<I.Check size={16}/>}    label="Interviews"    value={interviewed}     sub="This month so far" trend="+2 this week"/>
          <KpiCard tone="warn"    icon={<I.Sparkle size={16}/>}  label="Response rate" value={`${responseRate}%`} sub="Of applications sent"/>
        </div>
      </section>

      {/* === SECTION 2: Top matches — main content === */}
      <section>
        <SectionHead
          kicker="Top matches"
          title="Three roles worth a closer look."
          sub="Highest-scoring matches across your active filters."
          right={<Button variant="ghost" size="sm" onClick={() => onTab('matches')} iconRight={<I.Arrow size={12}/>}>See all matches</Button>}
        />
        <Card className="p-2 px-5">
          {loading ? Array.from({length:3}).map((_,i) => (
            <div key={i} className="flex items-center gap-3 py-3 border-b border-paper-200 last:border-0">
              <Skeleton className="w-[42px] h-[42px] !rounded-full" h={42}/>
              <div className="flex-1 space-y-2">
                <Skeleton h={12} w={'60%'}/>
                <Skeleton h={10} w={'40%'}/>
              </div>
            </div>
          )) : top3.length === 0 ? (
            <div className="py-12 text-center">
              <div className="w-12 h-12 rounded-2xl bg-paper-100 border border-paper-200 mx-auto flex items-center justify-center text-ink-400 mb-3">
                <I.Search size={20}/>
              </div>
              <div className="text-[14px] text-ink-700 font-medium">No matches yet</div>
              <div className="text-[12.5px] text-ink-500 mt-1">Agents are scanning — check back in a few minutes.</div>
            </div>
          ) : (
            <div className="divide-y divide-paper-200">
              {top3.map(j => <MiniMatchRow key={j.id} job={j} onReview={onReview}/>)}
            </div>
          )}
        </Card>
      </section>

      {/* === SECTION 3: Working in the background === */}
      <section>
        <SectionHead
          kicker="Background activity"
          title="Your agents, working quietly."
          sub="Four specialists scan, score, tailor, and quality-check every role."
          right={<Button variant="ghost" size="sm" onClick={() => document.getElementById('agent-center')?.scrollIntoView({ behavior:'smooth' })} iconRight={<I.Arrow size={12}/>}>Full status</Button>}
        />
        <Card className="p-5 divide-y divide-paper-200">
          {loading
            ? Array.from({length:4}).map((_, i) => (
              <div key={i} className="flex items-center gap-3 py-2.5">
                <Skeleton className="w-8 h-8 !rounded-lg" h={32}/>
                <div className="flex-1 space-y-2">
                  <Skeleton h={10} w={140}/>
                  <Skeleton h={8} w={200}/>
                </div>
              </div>
            ))
            : agents.map(a => <AgentPulse key={a.id} agent={a}/>)
          }
        </Card>
      </section>

      {/* === SECTION 4: Quick actions — the things you might do next === */}
      <section>
        <SectionHead kicker="Next steps" title="What you might do next."/>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
          {[
            { l:`Review your ${newCount} new matches`, s:'Top matches this morning',     ic:<I.Spark size={14}/>, on:() => onTab('matches')   },
            { l:`Resume ${savedCount} saved jobs`,      s:'Continue where you left off',  ic:<I.Bookmark size={14}/>, on:() => onTab('matches')},
            { l:'Update your CV',                       s:'Last edited 4 days ago',       ic:<I.Doc size={14}/>,   on:() => {}                  },
            { l:'Tune your preferences',                s:'Salary, location, role',       ic:<I.Settings size={14}/>, on:onAdjust              },
          ].map(a => (
            <button key={a.l} onClick={a.on} className="text-left p-4 bg-paper-0 border border-paper-200 rounded-2xl hover:border-brand-600 hover:shadow-pop transition-all group">
              <div className="w-9 h-9 rounded-xl bg-paper-100 text-ink-700 flex items-center justify-center group-hover:bg-brand-600 group-hover:text-white transition-colors">{a.ic}</div>
              <div className="text-[13.5px] font-semibold text-ink-900 mt-3 leading-tight">{a.l}</div>
              <div className="text-[12px] text-ink-500 mt-1">{a.s}</div>
              <div className="text-[12px] text-brand-600 font-medium mt-3 flex items-center gap-1 group-hover:gap-1.5 transition-all">Open <I.Arrow size={11}/></div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};

Object.assign(window, { Overview, KpiCard, AgentPulse });
