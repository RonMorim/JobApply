// JobApply — App shell with login flow, profile menu, redesigned header.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#2563EB",
  "showSearch": true
}/*EDITMODE-END*/;

const TABS = [
  { id: 'overview',   label: 'Overview',     icon: <I.Spark size={14}/> },
  { id: 'matches',    label: 'Matches',      icon: <I.Bolt  size={14}/> },
  { id: 'apps',       label: 'Applications', icon: <I.Doc   size={14}/> },
  { id: 'automation', label: 'Automation',   icon: <I.Robot size={14}/> },
];

function Header({ tab, setTab, onAdjust, onSignOut }) {
  const [profileOpen, setProfileOpen] = React.useState(false);
  const [notifsOpen,  setNotifsOpen]  = React.useState(false);

  return (
    <header className="sticky top-0 z-30 bg-paper-0/85 backdrop-blur-md border-b border-paper-200">
      <div className="max-w-[1240px] mx-auto px-6 lg:px-10 h-16 flex items-center gap-6">
        <Logo/>

        <nav className="hidden md:flex items-center gap-0.5 ml-4">
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`relative inline-flex items-center gap-1.5 h-9 px-3.5 rounded-full text-[13px] font-medium transition-colors ${tab === t.id ? 'text-ink-900 bg-paper-100' : 'text-ink-600 hover:text-ink-900 hover:bg-paper-50'}`}
            >
              <span className={tab === t.id ? 'text-brand-600' : 'text-ink-400'}>{t.icon}</span>
              {t.label}
              {tab === t.id && <span className="absolute -bottom-[17px] left-1/2 -translate-x-1/2 w-6 h-[2px] bg-brand-600 rounded-full"/>}
            </button>
          ))}
        </nav>

        <div className="flex-1"/>

        <div className="hidden lg:flex items-center gap-2 h-9 px-3 rounded-full bg-paper-50 border border-paper-200 text-ink-600 w-[260px] hover:border-paper-300 transition-colors">
          <I.Search size={14} className="text-ink-400"/>
          <input className="bg-transparent outline-none text-[13px] placeholder:text-ink-400 flex-1" placeholder="Search jobs, companies, skills…"/>
          <kbd className="text-[10px] font-mono text-ink-400 border border-paper-200 rounded px-1.5 py-0.5">⌘K</kbd>
        </div>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => { setNotifsOpen(v => !v); setProfileOpen(false); }}
            className={`relative w-9 h-9 rounded-full inline-flex items-center justify-center transition-all ${notifsOpen ? 'bg-brand-50 text-brand-600' : 'text-ink-600 hover:bg-paper-100 hover:text-ink-900'}`}
            title="Notifications"
          >
            <I.Bell size={16}/>
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-warn-500 ring-2 ring-paper-0"/>
          </button>
          {notifsOpen && <NotificationsMenu onClose={() => setNotifsOpen(false)}/>}
        </div>

        {/* Settings → automation */}
        <button
          onClick={() => setTab('automation')}
          className={`w-9 h-9 rounded-full inline-flex items-center justify-center transition-all ${tab === 'automation' ? 'bg-brand-50 text-brand-600' : 'text-ink-600 hover:bg-paper-100 hover:text-ink-900'}`}
          title="Automation settings"
        >
          <I.Settings size={16}/>
        </button>

        {/* Profile */}
        <div className="relative">
          <button
            onClick={() => { setProfileOpen(v => !v); setNotifsOpen(false); }}
            className={`flex items-center gap-2 pl-1 pr-2 h-9 rounded-full transition-colors ${profileOpen ? 'bg-paper-100' : 'hover:bg-paper-50'}`}
          >
            <span className="w-7 h-7 rounded-full bg-brand-600 text-white font-semibold text-[12px] flex items-center justify-center">AP</span>
            <span className="hidden sm:inline text-[12.5px] font-medium text-ink-900">Alex</span>
            <I.Arrow size={11} className={`text-ink-400 rotate-90 transition-transform ${profileOpen ? '-rotate-90' : ''}`}/>
          </button>
          {profileOpen && (
            <ProfileMenu
              onClose={() => setProfileOpen(false)}
              onSignOut={onSignOut}
              onNav={(id) => { if (id === 'automation') setTab('automation'); }}
            />
          )}
        </div>
      </div>
    </header>
  );
}

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Auth flow: 'login' | 'recruiter-block' | 'app'
  const [stage, setStage] = React.useState('login');

  const [tab, setTab] = React.useState('overview');
  const [jobs, setJobs] = React.useState(SEED_JOBS);
  const [apps] = React.useState(SEED_APPS);
  const [agents] = React.useState(SEED_AGENTS);
  const [loading, setLoading] = React.useState(true);

  const [report, setReport] = React.useState(null);

  const [settings, setSettings] = React.useState({
    autoApply: true, threshold: 82, dailyLimit: 25, dailyUsed: 14,
    tailor: true, skipDup: true, pauseOnRej: false, approveLow: false, salaryTarget: 130000,
  });

  React.useEffect(() => { const t = setTimeout(() => setLoading(false), 700); return () => clearTimeout(t); }, [stage]);

  const handleSignIn = (role) => setStage(role === 'recruiter' ? 'recruiter-block' : 'app');
  const handleSignOut = () => { setStage('login'); setTab('overview'); };

  const openReport = (job, mode = 'report') => setReport({ job, mode });
  const onApply    = (job) => setReport({ job, mode: 'integrity' });
  const onToggle   = (job) => setJobs(js => js.map(j => j.id === job.id ? { ...j, saved: !j.saved } : j));

  if (stage === 'login') return (
    <>
      <Login onSignIn={handleSignIn}/>
      <TweaksPanel title="Tweaks">
        <TweakSection title="Demo">
          <TweakButton onClick={() => handleSignIn('seeker')}>Skip to Seeker app</TweakButton>
          <TweakButton onClick={() => handleSignIn('recruiter')}>Skip to Recruiter screen</TweakButton>
        </TweakSection>
      </TweaksPanel>
    </>
  );

  if (stage === 'recruiter-block') return (
    <>
      <RecruiterComingSoon onBack={() => setStage('login')}/>
      <TweaksPanel title="Tweaks">
        <TweakSection title="Demo"><TweakButton onClick={() => setStage('login')}>Back to login</TweakButton></TweakSection>
      </TweaksPanel>
    </>
  );

  return (
    <div className="min-h-screen bg-paper-50">
      <Header tab={tab} setTab={setTab} onAdjust={() => setTab('automation')} onSignOut={handleSignOut}/>

      <main className="max-w-[1240px] mx-auto px-6 lg:px-10 py-10">
        {tab === 'overview' ? (
          <Overview
            jobs={jobs} apps={apps} agents={agents} settings={settings}
            loading={loading}
            onTab={setTab}
            onAdjust={() => setTab('automation')}
            onReview={(j) => openReport(j, 'report')}
          />
        ) : tab === 'matches' ? (
          <MatchFeed jobs={jobs} onReview={(j) => openReport(j, 'report')} onApply={onApply} onToggleSave={onToggle}/>
        ) : tab === 'apps' ? (
          <Tracker apps={apps}/>
        ) : (
          <AutomationPage settings={settings} setSettings={setSettings}/>
        )}

        {tab === 'overview' && <div className="mt-12"><AgentStatusCenter agents={agents} onConfigure={() => setTab('automation')}/></div>}
      </main>

      <footer className="max-w-[1240px] mx-auto px-6 lg:px-10 py-10 text-[12px] text-ink-400 flex items-center justify-between border-t border-paper-200 mt-8">
        <span>© 2026 Job Apply · Quiet automation for thoughtful careers.</span>
        <span className="num">v1.0 · build 312</span>
      </footer>

      {report && (
        <ReportDrawer
          job={report.job}
          mode={report.mode}
          onSwitchMode={(m) => setReport(r => ({ ...r, mode: m }))}
          onClose={() => setReport(null)}
        />
      )}

      <TweaksPanel title="Tweaks">
        <TweakSection title="Navigation">
          <TweakButton onClick={() => setTab('overview')}>Go to Overview</TweakButton>
          <TweakButton onClick={() => setTab('matches')}>Go to Matches</TweakButton>
          <TweakButton onClick={() => setTab('apps')}>Go to Applications</TweakButton>
          <TweakButton onClick={() => setTab('automation')}>Go to Automation</TweakButton>
        </TweakSection>
        <TweakSection title="Quick demos">
          <TweakButton onClick={() => openReport(jobs[0], 'report')}>Open Recruiter Brief</TweakButton>
          <TweakButton onClick={() => openReport(jobs[0], 'integrity')}>Open Confidence Optimizer</TweakButton>
          <TweakButton onClick={handleSignOut}>Sign out → Login</TweakButton>
        </TweakSection>
        <TweakSection title="Demo data">
          <TweakButton onClick={() => setSettings(s => ({ ...s, dailyUsed: Math.min(s.dailyLimit, s.dailyUsed + 3) }))}>+3 applications today</TweakButton>
          <TweakButton onClick={() => setJobs(js => js.map(j => ({ ...j, isNew: true })))}>Mark all new</TweakButton>
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
