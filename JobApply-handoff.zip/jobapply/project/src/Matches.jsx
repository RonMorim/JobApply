// Matches tab — filter bar + MatchCard list.

const FILTERS = [
  { id: 'all',    label: 'All'           },
  { id: 'new',    label: 'New'           },
  { id: 'strong', label: 'Strong (85+)'  },
  { id: 'remote', label: 'Remote'        },
  { id: 'saved',  label: 'Saved'         },
];

const SORTS = [
  { id: 'match',  label: 'Match score' },
  { id: 'newest', label: 'Newest'      },
  { id: 'oldest', label: 'Oldest'      },
];

const MatchCard = ({ job, onReview, onApply, onToggleSave }) => (
  <article className="bg-paper-0 border border-paper-200 rounded-xl2 shadow-card p-5 hover:border-paper-300 hover:shadow-pop transition-all">
    <div className="flex items-start gap-5">
      <ScoreRing score={job.score} size={64} stroke={5}/>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          {job.isNew && (
            <span className="inline-flex items-center gap-1 text-[10.5px] uppercase tracking-[0.14em] font-semibold text-ember-500">
              <span className="w-1.5 h-1.5 rounded-full bg-ember-400 pulse-dot"/>
              New
            </span>
          )}
          <h3 className="text-[17px] font-semibold text-ink-900 leading-tight">{job.title}</h3>
        </div>
        <div className="text-[13px] text-ink-600 mt-1">
          <span className="font-medium text-ink-800">{job.company}</span>
          <span className="text-ink-300 mx-1.5">·</span>
          {job.location}
          <span className="text-ink-300 mx-1.5">·</span>
          {job.postedAt}
          {job.salary && <>
            <span className="text-ink-300 mx-1.5">·</span>
            <span className="num">{job.salary}</span>
          </>}
        </div>

        <div className="flex flex-wrap gap-1.5 mt-3">
          {job.reasons.map((r, i) => <ReasonTag key={i} kind={r.kind} label={r.label}/>)}
        </div>
      </div>

      <div className="flex flex-col items-end gap-2 shrink-0">
        <div className="flex items-center gap-2">
          <IconBtn onClick={() => onToggleSave(job)} active={job.saved} title={job.saved ? 'Saved' : 'Save'}>
            <I.Bookmark size={15} filled={job.saved}/>
          </IconBtn>
          <Button variant="secondary" size="md" icon={<I.Doc size={14}/>} onClick={() => onReview(job)}>Review CV</Button>
          <Button variant="primary" size="md" icon={<I.Bolt size={14}/>} onClick={() => onApply(job)}>Apply</Button>
        </div>
        <div className="text-[11px] text-ink-400 num">Match #{job.postedRank}</div>
      </div>
    </div>
  </article>
);

const MatchFeed = ({ jobs, error, onReview, onApply, onToggleSave }) => {
  const [filter, setFilter] = React.useState('all');
  const [sort,   setSort]   = React.useState('match');

  const filtered = React.useMemo(() => {
    let list = [...jobs];
    if (filter === 'new')    list = list.filter(j => j.isNew);
    if (filter === 'strong') list = list.filter(j => j.score >= 85);
    if (filter === 'remote') list = list.filter(j => /remote/i.test(j.location));
    if (filter === 'saved')  list = list.filter(j => j.saved);
    if (sort === 'match')  list.sort((a,b) => b.score - a.score);
    if (sort === 'newest') list.sort((a,b) => a.postedRank - b.postedRank);
    if (sort === 'oldest') list.sort((a,b) => b.postedRank - a.postedRank);
    return list;
  }, [jobs, filter, sort]);

  return (
    <div className="anim-fade">
      <SectionHead
        kicker="Matches"
        title="Your matches, ranked by fit."
        sub="Updated continuously. Review the recruiter brief on each one before you apply."
      />

      {error && (
        <div className="mb-4 p-3.5 rounded-xl2 bg-ember-50 border border-ember-100 flex items-center justify-between">
          <div className="text-[13px] text-ember-600">Could not load matches — {error}</div>
          <Button variant="danger" size="sm" icon={<I.Refresh size={14}/>}>Retry</Button>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <div className="inline-flex p-1 rounded-full bg-paper-100 border border-paper-200">
          {FILTERS.map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`h-8 px-3.5 rounded-full text-[12.5px] font-medium transition-colors ${filter === f.id ? 'bg-paper-0 text-ink-900 shadow-card' : 'text-ink-600 hover:text-ink-900'}`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[12px] text-ink-500 num">{filtered.length} results</span>
          <div className="inline-flex items-center gap-1.5 h-8 px-3 rounded-full bg-paper-0 border border-paper-300 text-[12.5px] text-ink-700">
            <I.Filter size={13} className="text-ink-400"/>
            <span className="text-ink-500">Sort:</span>
            <select value={sort} onChange={e => setSort(e.target.value)} className="bg-transparent outline-none text-ink-900 font-medium pr-1">
              {SORTS.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card className="py-16 text-center">
          <div className="text-[14px] text-ink-500">No matches in this view yet.</div>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map(j => (
            <MatchCard key={j.id} job={j} onReview={onReview} onApply={onApply} onToggleSave={onToggleSave}/>
          ))}
        </div>
      )}
    </div>
  );
};

Object.assign(window, { MatchFeed, MatchCard });
