// Login screen with role select + Recruiter Coming Soon screen + Profile menu.

const RoleCard = ({ role, label, sub, icon, selected, onSelect, accent }) => (
  <button
    type="button"
    onClick={() => onSelect(role)}
    className={`text-left p-5 rounded-2xl border-2 transition-all w-full ${selected ? 'border-brand-600 bg-brand-50/40 shadow-card' : 'border-paper-200 bg-paper-0 hover:border-paper-300 hover:bg-paper-50'}`}
  >
    <div className="flex items-start gap-4">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${selected ? 'bg-brand-600 text-white' : `${accent} text-ink-700`}`}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <div className="text-[15px] font-semibold text-ink-900">{label}</div>
          {selected && <I.Check size={14} className="text-brand-600"/>}
        </div>
        <div className="text-[12.5px] text-ink-500 mt-1 leading-snug">{sub}</div>
      </div>
    </div>
  </button>
);

const Login = ({ onSignIn }) => {
  const [role, setRole] = React.useState('seeker');
  const [email, setEmail] = React.useState('alex@example.com');
  const [pw, setPw]       = React.useState('••••••••');
  const [showPw, setShowPw] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);

  const submit = (e) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => onSignIn(role), 500);
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left — form */}
      <div className="flex flex-col px-6 sm:px-12 py-8 bg-paper-0">
        <div className="flex items-center justify-between">
          <Logo/>
          <div className="text-[12.5px] text-ink-500">New here? <a href="#" className="text-brand-600 font-medium hover:underline">Create account</a></div>
        </div>

        <div className="flex-1 flex items-center">
          <div className="w-full max-w-[440px] mx-auto py-12">
            <SectionLabel>Sign in</SectionLabel>
            <h1 className="display text-[34px] leading-[1.1] mt-2 text-ink-900 font-semibold">Welcome back.</h1>
            <p className="text-[14px] text-ink-600 mt-2">Choose how you'll be using Job Apply today.</p>

            {/* Role select */}
            <div className="grid gap-3 mt-7">
              <RoleCard
                role="seeker"
                label="I'm a Job Seeker"
                sub="Get matched, tailor applications, and track everything in one place."
                icon={<I.User size={20}/>}
                selected={role === 'seeker'}
                onSelect={setRole}
                accent="bg-brand-50"
              />
              <RoleCard
                role="recruiter"
                label="I'm a Recruiter"
                sub="Source, screen, and hire with the same agents working in your favor."
                icon={<I.Briefcase size={20}/>}
                selected={role === 'recruiter'}
                onSelect={setRole}
                accent="bg-warn-50"
              />
            </div>

            <form onSubmit={submit} className="mt-7 space-y-3">
              <div>
                <label className="text-[12px] font-medium text-ink-700">Work email</label>
                <div className="mt-1.5 flex items-center gap-2 px-3 h-11 rounded-xl border border-paper-300 bg-paper-50 focus-within:border-brand-600 focus-within:bg-paper-0 focus-within:shadow-focus transition-all">
                  <I.Mail size={15} className="text-ink-400"/>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="flex-1 bg-transparent text-[13.5px] text-ink-900 outline-none"/>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between">
                  <label className="text-[12px] font-medium text-ink-700">Password</label>
                  <a href="#" className="text-[12px] text-brand-600 hover:underline">Forgot?</a>
                </div>
                <div className="mt-1.5 flex items-center gap-2 px-3 h-11 rounded-xl border border-paper-300 bg-paper-50 focus-within:border-brand-600 focus-within:bg-paper-0 focus-within:shadow-focus transition-all">
                  <I.Lock size={15} className="text-ink-400"/>
                  <input type={showPw ? 'text' : 'password'} value={pw} onChange={e => setPw(e.target.value)} className="flex-1 bg-transparent text-[13.5px] text-ink-900 outline-none"/>
                  <button type="button" onClick={() => setShowPw(s => !s)} className="text-ink-400 hover:text-ink-700"><I.Eye size={14}/></button>
                </div>
              </div>

              <Button variant="primary" size="lg" type="submit" className="w-full mt-2" disabled={submitting}>
                {submitting ? 'Signing you in…' : `Continue as ${role === 'seeker' ? 'Job Seeker' : 'Recruiter'}`}
              </Button>

              <div className="flex items-center gap-3 my-3">
                <div className="hair flex-1"/>
                <span className="text-[11px] uppercase tracking-wider text-ink-400 font-medium">or</span>
                <div className="hair flex-1"/>
              </div>

              <button type="button" className="w-full h-11 rounded-xl border border-paper-300 bg-paper-0 hover:bg-paper-50 flex items-center justify-center gap-2 text-[13.5px] font-medium text-ink-800 transition-colors">
                <I.Google size={16}/>
                Continue with Google
              </button>
            </form>

            <div className="text-[11.5px] text-ink-500 mt-6 leading-relaxed">
              By continuing you agree to our <a className="text-ink-900 hover:underline" href="#">Terms</a> and <a className="text-ink-900 hover:underline" href="#">Privacy Policy</a>. Recruiter accounts require verification.
            </div>
          </div>
        </div>

        <div className="text-[11.5px] text-ink-400">© 2026 Job Apply</div>
      </div>

      {/* Right — visual */}
      <div className="hidden lg:flex relative bg-brand-600 overflow-hidden">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(ellipse at top right, rgba(255,255,255,.18), transparent 60%), radial-gradient(ellipse at bottom left, rgba(250,204,21,.25), transparent 55%)'
        }}/>
        <div className="relative z-10 flex flex-col justify-between p-12 w-full text-white">
          <div className="flex items-center gap-2 text-[12.5px] font-medium opacity-90">
            <span className="w-1.5 h-1.5 rounded-full bg-ok-500 pulse-dot"/>
            Live · 4 agents working
          </div>
          <div>
            <div className="text-[13px] uppercase tracking-[0.16em] font-semibold opacity-80">Quiet automation</div>
            <h2 className="display text-[44px] leading-[1.05] mt-3 font-semibold">Your career, on autopilot — with a co-pilot on call.</h2>
            <p className="text-[15px] opacity-85 mt-4 max-w-[44ch] leading-relaxed">Four specialist agents scan, match, tailor, and review every role you apply to. You stay in the driver's seat.</p>
            <div className="mt-7 grid grid-cols-3 gap-4">
              {[
                { k:'Matches reviewed', v:'1,284', s:'this week' },
                { k:'Avg. match score', v:'82', s:'across pipeline' },
                { k:'Response rate',    v:'48%', s:'+11 vs market' },
              ].map(s => (
                <div key={s.k} className="bg-white/10 backdrop-blur-sm rounded-xl p-3 border border-white/10">
                  <div className="text-[11px] uppercase tracking-wider opacity-70 font-medium">{s.k}</div>
                  <div className="num text-[22px] font-semibold mt-1">{s.v}</div>
                  <div className="text-[11px] opacity-70">{s.s}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="text-[12px] opacity-70">Trusted by designers, engineers, and PMs at Stripe, Linear, Anthropic, and more.</div>
        </div>
      </div>
    </div>
  );
};

// ---- Recruiter Coming Soon ----
const RecruiterComingSoon = ({ onBack }) => (
  <div className="min-h-screen flex flex-col">
    <header className="px-6 lg:px-10 h-16 flex items-center justify-between border-b border-paper-200">
      <Logo/>
      <Button variant="ghost" size="sm" onClick={onBack} icon={<I.Switch size={13}/>}>Switch account</Button>
    </header>
    <main className="flex-1 flex items-center justify-center px-6 py-12">
      <div className="max-w-[560px] w-full text-center">
        <div className="w-16 h-16 rounded-2xl bg-warn-50 border border-warn-200 mx-auto flex items-center justify-center text-warn-600">
          <I.Lock size={26}/>
        </div>
        <Pill tone="warn" className="mt-5">
          <span className="w-1.5 h-1.5 rounded-full bg-warn-500 pulse-dot"/>
          Coming soon · Q3 2026
        </Pill>
        <h1 className="display text-[36px] leading-[1.1] text-ink-900 font-semibold mt-4">The Recruiter side is being built.</h1>
        <p className="text-[15px] text-ink-600 mt-3 leading-relaxed">
          Access is restricted to <span className="font-medium text-ink-900">verified recruiters</span> from approved employers. We're hand-rolling the onboarding to make sure the candidates we surface are legit and the pipelines are clean.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-8 text-left">
          {[
            { i: <I.Briefcase size={16}/>, t:'Verified employers',  s:'Domain + ATS check' },
            { i: <I.Robot size={16}/>,     t:'Same agent stack',    s:'Match, screen, brief' },
            { i: <I.Shield size={16}/>,    t:'Privacy-first',       s:'No public profiles' },
          ].map(c => (
            <div key={c.t} className="p-4 rounded-xl border border-paper-200 bg-paper-0">
              <div className="w-8 h-8 rounded-lg bg-brand-50 text-brand-600 flex items-center justify-center">{c.i}</div>
              <div className="text-[13.5px] font-semibold text-ink-900 mt-3">{c.t}</div>
              <div className="text-[12px] text-ink-500 mt-0.5">{c.s}</div>
            </div>
          ))}
        </div>

        <form className="mt-8 flex gap-2 max-w-[420px] mx-auto" onSubmit={e => e.preventDefault()}>
          <div className="flex-1 flex items-center gap-2 px-3 h-11 rounded-xl border border-paper-300 bg-paper-0 focus-within:border-brand-600 focus-within:shadow-focus">
            <I.Mail size={15} className="text-ink-400"/>
            <input type="email" placeholder="you@company.com" className="flex-1 bg-transparent text-[13.5px] text-ink-900 outline-none"/>
          </div>
          <Button variant="primary" size="lg" type="submit">Request access</Button>
        </form>
        <div className="text-[12px] text-ink-500 mt-3">We'll review and reach out within 1 business day.</div>

        <div className="mt-10">
          <Button variant="ghost" size="md" onClick={onBack} icon={<I.Arrow size={13} className="rotate-180"/>}>Back to sign in</Button>
        </div>
      </div>
    </main>
  </div>
);

// ---- ProfileMenu ----
const ProfileMenu = ({ onClose, onSignOut, onNav }) => {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); };
  }, [onClose]);

  const items = [
    { id:'profile',   label:'Your profile',     sub:'Resume, skills, links',     icon:<I.User size={14}/>, kbd:'⇧P' },
    { id:'prefs',     label:'Preferences',      sub:'Salary, location, role',    icon:<I.Sparkle size={14}/> },
    { id:'automation',label:'Automation',       sub:'Auto-Apply rules & limits', icon:<I.Robot size={14}/>, kbd:'A' },
    { id:'billing',   label:'Plan & billing',   sub:'Pro · €9 / month',          icon:<I.Briefcase size={14}/> },
    { id:'help',      label:'Help & feedback',  sub:'Docs, contact, shortcuts',  icon:<I.Help size={14}/>, kbd:'?' },
  ];

  return (
    <div ref={ref} className="absolute right-0 top-full mt-2 w-[300px] bg-paper-0 border border-paper-200 rounded-2xl shadow-menu anim-menu z-50 overflow-hidden">
      {/* Identity */}
      <div className="p-4 flex items-center gap-3 border-b border-paper-200">
        <div className="w-10 h-10 rounded-full bg-brand-600 text-white font-semibold text-[14px] flex items-center justify-center">AP</div>
        <div className="min-w-0 flex-1">
          <div className="text-[13.5px] font-semibold text-ink-900 truncate">Alex Park</div>
          <div className="text-[12px] text-ink-500 truncate">alex@example.com</div>
        </div>
        <Pill tone="brand" className="!h-6">Pro</Pill>
      </div>

      {/* Items */}
      <ul className="py-1.5">
        {items.map(it => (
          <li key={it.id}>
            <button onClick={() => { onNav(it.id); onClose(); }} className="w-full flex items-center gap-3 px-3 py-2 hover:bg-paper-50 text-left transition-colors group">
              <span className="w-8 h-8 rounded-lg bg-paper-100 text-ink-700 flex items-center justify-center group-hover:bg-brand-50 group-hover:text-brand-600 transition-colors">{it.icon}</span>
              <span className="flex-1 min-w-0">
                <span className="block text-[13px] font-medium text-ink-900 leading-tight">{it.label}</span>
                <span className="block text-[11.5px] text-ink-500 truncate">{it.sub}</span>
              </span>
              {it.kbd && <kbd className="text-[10px] font-mono text-ink-400 border border-paper-200 rounded px-1.5 py-0.5">{it.kbd}</kbd>}
            </button>
          </li>
        ))}
      </ul>

      {/* Footer */}
      <div className="border-t border-paper-200 p-2">
        <button onClick={onSignOut} className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-danger-50 text-danger-600 text-[13px] font-medium transition-colors">
          <I.Logout size={14}/>
          Sign out
        </button>
      </div>
    </div>
  );
};

// ---- NotificationsMenu ----
const NotificationsMenu = ({ onClose }) => {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [onClose]);

  const items = [
    { tone:'success', icon:<I.Check size={13}/>, t:'Offer received from Rivet Works', s:'2h ago · Senior Designer · Open in tracker', unread:true },
    { tone:'brand',   icon:<I.Spark size={13}/>, t:'3 new strong matches today',      s:'4h ago · Linear Orbit, Harbor AI, Northwind', unread:true },
    { tone:'warn',    icon:<I.Sparkle size={13}/>, t:'Auto-Apply paused — daily cap',  s:'Yesterday · 25/25 sent', unread:false },
    { tone:'brand',   icon:<I.Mail size={13}/>,  t:'Cedar Labs scheduled an interview', s:'Yesterday · Tue, May 6 at 2pm', unread:false },
  ];

  return (
    <div ref={ref} className="absolute right-0 top-full mt-2 w-[360px] bg-paper-0 border border-paper-200 rounded-2xl shadow-menu anim-menu z-50 overflow-hidden">
      <div className="px-4 py-3 flex items-center justify-between border-b border-paper-200">
        <div className="flex items-center gap-2">
          <span className="text-[13.5px] font-semibold text-ink-900">Notifications</span>
          <Pill tone="brand" className="!h-5 !text-[10.5px]">2 new</Pill>
        </div>
        <button className="text-[12px] text-ink-500 hover:text-ink-900">Mark all read</button>
      </div>
      <ul className="max-h-[360px] overflow-y-auto drawer-scroll">
        {items.map((n, i) => (
          <li key={i} className={`flex items-start gap-3 px-4 py-3 hover:bg-paper-50 cursor-pointer transition-colors ${n.unread ? 'bg-brand-50/30' : ''}`}>
            <span className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
              n.tone === 'success' ? 'bg-ok-50 text-ok-600' :
              n.tone === 'warn' ? 'bg-warn-50 text-warn-600' :
              'bg-brand-50 text-brand-600'
            }`}>{n.icon}</span>
            <div className="flex-1 min-w-0">
              <div className="text-[12.5px] font-medium text-ink-900 leading-snug">{n.t}</div>
              <div className="text-[11.5px] text-ink-500 mt-0.5 leading-snug">{n.s}</div>
            </div>
            {n.unread && <span className="w-2 h-2 rounded-full bg-brand-600 mt-1.5 shrink-0"/>}
          </li>
        ))}
      </ul>
      <div className="px-4 py-2.5 border-t border-paper-200 text-center">
        <button className="text-[12px] font-medium text-brand-600 hover:underline">View all activity</button>
      </div>
    </div>
  );
};

Object.assign(window, { Login, RecruiterComingSoon, ProfileMenu, NotificationsMenu });
