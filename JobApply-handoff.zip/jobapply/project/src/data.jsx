// Seed data for the JobApply prototype.
// Mirrors the data models in the spec.

const SEED_JOBS = [
  {
    id: 'j1',
    title: 'Senior Product Designer, Platform',
    company: 'Linear Orbit',
    location: 'Remote · EU',
    postedAt: '4h ago',
    postedRank: 1,
    score: 94,
    isNew: true,
    saved: false,
    salary: '€110–135k',
    reasons: [
      { kind: 'skill', label: 'Design systems · 7y' },
      { kind: 'skill', label: 'Figma · expert' },
      { kind: 'exp',   label: 'Platform tooling' },
      { kind: 'loc',   label: 'Remote-friendly' },
    ],
    whyRon: `# Why this is a strong match
—A platform-shaped role for a platform-shaped designer—

OVERVIEW
This role sits at the seam between Linear Orbit's design system and its public API surface — exactly the territory you've spent the last four years owning at your current company. The hiring manager (ex-Stripe, ex-Linear) is biased toward designers who can ship into production code, which aligns with your hands-on track record.

━━━━━━━━━━━━

SKILL ALIGNMENT
★★★★★  Design systems
    Owned tokens, primitives, and migration tooling at scale.
★★★★★  Figma & component architecture
    Authored a 240-component library currently used by 80+ designers.
★★★★☆  Frontend literacy (TS / React)
    Ships PRs to the system repo monthly; reviewed by FE.
★★★☆☆  Public API design
    Adjacent experience via SDK docs; would stretch here.

━━━━━━━━━━━━

WHAT TO HIGHLIGHT
1. The migration from Sketch → Figma you led, with the metric on adoption velocity.
2. Your essay on "stable primitives, unstable surfaces" — directly mirrors their JD language.
3. The internal tool you shipped for cross-team token review — closest analogue to their stated Q3 priority.

WATCH-OUTS
1. They explicitly want someone comfortable presenting to engineering leadership weekly. Worth pre-empting in cover letter.
2. Salary band tops out at €135k; below your last ask of €145k. Negotiable on equity.`,
  },
  {
    id: 'j2',
    title: 'Principal Designer, AI Products',
    company: 'Harbor AI',
    location: 'London / Hybrid',
    postedAt: '6h ago',
    postedRank: 2,
    score: 91,
    isNew: true,
    saved: true,
    salary: '£140–170k',
    reasons: [
      { kind: 'skill', label: 'AI/LLM UX · 2y' },
      { kind: 'exp',   label: 'IC Principal level' },
      { kind: 'loc',   label: 'London hybrid' },
    ],
    whyRon: `# Why this is a strong match
—Principal IC, AI surface, your sweet spot—

OVERVIEW
Harbor's stage (Series B, ~80 people) and IC-track ladder match the shape you said you wanted. The principal opening exists because their previous lead moved into management; the hiring loop is calibrated against ex-Anthropic and ex-Adept seniors.

SKILL ALIGNMENT
★★★★★  Conversational & agentic UX
★★★★★  Information density / prosumer tools
★★★★☆  Prototyping with code
★★★☆☆  ML literacy
    They state "you don't need to train models, but you need to feel them." Your last six months covers this.

WHAT TO HIGHLIGHT
1. The agent-routing UI you ran inside your hackweek — same problem space.
2. Your writing on "tools that disagree with you" — they linked it in the JD.

WATCH-OUTS
1. Hybrid means 2 days London. Confirm relocation expectations.`,
  },
  {
    id: 'j3',
    title: 'Staff UX Researcher',
    company: 'Northwind Health',
    location: 'Remote · US/EU',
    postedAt: '11h ago',
    postedRank: 3,
    score: 88,
    isNew: true,
    saved: false,
    salary: '$160–195k',
    reasons: [
      { kind: 'skill', label: 'Mixed-methods research' },
      { kind: 'exp',   label: 'Regulated industry' },
      { kind: 'loc',   label: 'Remote · global' },
    ],
    whyRon: '',
  },
  {
    id: 'j4',
    title: 'Senior Designer, Growth',
    company: 'Fernway',
    location: 'Berlin',
    postedAt: '1d ago',
    postedRank: 4,
    score: 82,
    isNew: false,
    saved: false,
    salary: '€95–115k',
    reasons: [
      { kind: 'skill', label: 'Activation & onboarding' },
      { kind: 'exp',   label: 'B2C scale' },
      { kind: 'neg',   label: 'On-site only' },
    ],
    whyRon: '',
  },
  {
    id: 'j5',
    title: 'Lead Designer, Design Systems',
    company: 'Quillford',
    location: 'Remote · EU',
    postedAt: '2d ago',
    postedRank: 5,
    score: 79,
    isNew: false,
    saved: true,
    salary: '€100–125k',
    reasons: [
      { kind: 'skill', label: 'Design systems · 7y' },
      { kind: 'exp',   label: 'Cross-functional lead' },
      { kind: 'loc',   label: 'EU hours' },
    ],
    whyRon: '',
  },
  {
    id: 'j6',
    title: 'Product Designer II',
    company: 'Pallet & Co.',
    location: 'NYC',
    postedAt: '3d ago',
    postedRank: 6,
    score: 71,
    isNew: false,
    saved: false,
    salary: '$130–155k',
    reasons: [
      { kind: 'skill', label: 'B2B SaaS' },
      { kind: 'neg',   label: 'Below seniority' },
      { kind: 'neg',   label: 'NYC only' },
    ],
    whyRon: '',
  },
];

const SEED_APPS = [
  { id: 'a1', title: 'Senior Product Designer', company: 'Cedar Labs',  when: 'Today',       stage: 'interview' },
  { id: 'a2', title: 'Lead Designer',           company: 'Kite & Kin',  when: 'Today',       stage: 'screening' },
  { id: 'a3', title: 'Staff Designer',          company: 'Rivet Works', when: '2 days ago',  stage: 'offer'     },
  { id: 'a4', title: 'Senior Designer',         company: 'Marbletown',  when: 'Yesterday',   stage: 'viewed'    },
  { id: 'a5', title: 'Product Designer',        company: 'Northfield',  when: 'Yesterday',   stage: 'submitted' },
  { id: 'a6', title: 'Senior Designer',         company: 'Tidecaster',  when: '3 days ago',  stage: 'rejected'  },
];

const SEED_AGENTS = [
  {
    id: 'scraper', name: 'Scraper', role: 'Sourcing crawler',
    state: 'active',
    current_task: 'Indexing 12 boards · linear.com/careers',
    queue_msg: '', error_msg: '',
    stats: { today: 1284, queue: 7, spark: [3,5,8,4,9,12,7,11] },
  },
  {
    id: 'sourcing', name: 'Sourcing Specialist', role: 'Match analysis',
    state: 'active',
    current_task: 'Scoring batch · 24 jobs in flight',
    queue_msg: '', error_msg: '',
    stats: { today: 312, queue: 24, spark: [4,6,5,8,11,9,13,10] },
  },
  {
    id: 'content', name: 'Content Strategist', role: 'Cover-letter tailor',
    state: 'queued',
    current_task: '',
    queue_msg: 'Waiting on 3 strong matches',
    error_msg: '',
    stats: { today: 41, queue: 3, spark: [1,2,1,3,2,4,2,3] },
  },
  {
    id: 'quality', name: 'Quality Guard', role: 'Pre-submit reviewer',
    state: 'idle',
    current_task: '',
    queue_msg: 'No items pending',
    error_msg: '',
    stats: { today: 38, queue: 0, spark: [2,1,3,2,4,1,2,2] },
  },
];

const STAGE_META = {
  submitted: { label: 'Submitted', tone: 'muted',   pulse: false },
  viewed:    { label: 'Viewed',    tone: 'primary', pulse: false },
  screening: { label: 'Screening', tone: 'primary', pulse: false },
  interview: { label: 'Interview', tone: 'success', pulse: true  },
  offer:     { label: 'Offer',     tone: 'success', pulse: true  },
  rejected:  { label: 'Rejected',  tone: 'muted',   pulse: false },
};

const REASON_META = {
  skill: { tone: 'forest', label: 'Skill'    },
  exp:   { tone: 'sky',    label: 'Exp'      },
  loc:   { tone: 'plum',   label: 'Location' },
  neg:   { tone: 'ember',  label: 'Watch'    },
};

Object.assign(window, { SEED_JOBS, SEED_APPS, SEED_AGENTS, STAGE_META, REASON_META });
