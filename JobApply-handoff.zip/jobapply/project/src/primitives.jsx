// JobApply UI primitives — Inter, white/blue/green/yellow palette.

// ----- Logo -----
const Logo = ({ size = 22 }) => (
  <div className="flex items-center gap-2 select-none">
    <span className="relative inline-flex items-center justify-center" style={{ width: size+4, height: size+4 }}>
      <svg viewBox="0 0 24 24" width={size+4} height={size+4}>
        <rect x="1" y="1" width="22" height="22" rx="6" fill="#2563EB"/>
        <path d="M7 9.5l4.2 5.5 5-9" stroke="#FFFFFF" strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </span>
    <span className="font-semibold tracking-tight text-ink-900 text-[15px]">Job Apply</span>
  </div>
);

// ----- StatusDot -----
const STATUS_DOT_TONES = {
  success: '#10B981',
  warn:    '#EAB308',
  danger:  '#EF4444',
  primary: '#2563EB',
  brand:   '#2563EB',
  muted:   '#9CA3AF',
};
const StatusDot = ({ tone = 'muted', pulse = false, size = 8 }) => (
  <span className="relative inline-flex" style={{ width: size, height: size }}>
    {pulse && (
      <span className="absolute inset-0 rounded-full pulse-dot" style={{ background: STATUS_DOT_TONES[tone], opacity: .35 }}/>
    )}
    <span className="rounded-full" style={{ width: size, height: size, background: STATUS_DOT_TONES[tone] }}/>
  </span>
);

// ----- Pill -----
const PILL_TONES = {
  default: 'bg-paper-100 text-ink-700 border-paper-200',
  brand:   'bg-brand-50 text-brand-700 border-brand-100',
  success: 'bg-ok-50 text-ok-700 border-ok-100',
  warn:    'bg-warn-50 text-warn-700 border-warn-200',
  danger:  'bg-danger-50 text-danger-700 border-danger-100',
  ink:     'bg-ink-900 text-white border-ink-900',
  outline: 'bg-paper-0 text-ink-700 border-paper-200',
  // legacy aliases for old kinds
  forest:  'bg-ok-50 text-ok-700 border-ok-100',
  sky:     'bg-brand-50 text-brand-700 border-brand-100',
  plum:    'bg-brand-50 text-brand-700 border-brand-100',
  ember:   'bg-warn-50 text-warn-700 border-warn-200',
};
const Pill = ({ tone = 'default', children, className = '', icon = null }) => (
  <span className={`inline-flex items-center gap-1.5 px-2 h-6 rounded-full text-[11.5px] font-medium border ${PILL_TONES[tone]} ${className}`}>
    {icon}
    {children}
  </span>
);

// ----- Button -----
const Button = ({ variant = 'primary', size = 'md', children, className = '', icon = null, iconRight = null, ...rest }) => {
  const sizes = {
    sm: 'h-8 px-3 text-[12.5px] gap-1.5',
    md: 'h-9 px-3.5 text-[13px] gap-2',
    lg: 'h-11 px-5 text-[14px] gap-2',
  };
  const variants = {
    primary:   'bg-brand-600 text-white hover:bg-brand-700 border border-brand-700 shadow-card',
    accent:    'bg-brand-600 text-white hover:bg-brand-700 border border-brand-700 shadow-card',
    success:   'bg-ok-600 text-white hover:bg-ok-700 border border-ok-700 shadow-card',
    secondary: 'bg-paper-0 text-ink-900 hover:bg-paper-50 border border-paper-200 shadow-card',
    ghost:     'bg-transparent text-ink-700 hover:bg-paper-100 border border-transparent',
    quiet:     'bg-paper-100 text-ink-800 hover:bg-paper-200 border border-paper-200',
    danger:    'bg-paper-0 text-danger-600 border border-danger-100 hover:bg-danger-50',
  };
  return (
    <button className={`inline-flex items-center justify-center rounded-full font-medium transition-colors ${sizes[size]} ${variants[variant]} ${className}`} {...rest}>
      {icon}
      {children}
      {iconRight}
    </button>
  );
};

// ----- IconBtn -----
const IconBtn = ({ children, active = false, className = '', size = 'md', ...rest }) => {
  const dims = size === 'sm' ? 'w-8 h-8' : 'w-9 h-9';
  return (
    <button className={`${dims} inline-flex items-center justify-center rounded-full border transition-all ${active ? 'bg-ink-900 text-white border-ink-900' : 'bg-paper-0 text-ink-700 border-paper-200 hover:bg-paper-50 hover:border-paper-300 hover:text-ink-900'} ${className}`} {...rest}>
      {children}
    </button>
  );
};

// ----- Toggle -----
const Toggle = ({ checked, onChange, label, sub }) => (
  <label className="flex items-start justify-between gap-4 cursor-pointer py-1">
    <div className="min-w-0">
      {label && <div className="text-[13.5px] text-ink-900 font-medium leading-tight">{label}</div>}
      {sub && <div className="text-[12px] text-ink-500 leading-snug mt-0.5">{sub}</div>}
    </div>
    <button
      type="button"
      onClick={() => onChange?.(!checked)}
      aria-pressed={checked}
      className={`shrink-0 w-[38px] h-[22px] rounded-full transition-colors relative ${checked ? 'bg-brand-600' : 'bg-paper-300'}`}
    >
      <span className={`absolute top-[2px] w-[18px] h-[18px] rounded-full bg-white shadow-card transition-all ${checked ? 'left-[18px]' : 'left-[2px]'}`}/>
    </button>
  </label>
);

// ----- Skeleton -----
const Skeleton = ({ className = '', h = 12, w }) => (
  <div className={`skeleton rounded-md ${className}`} style={{ height: h, width: w }}/>
);

// ----- ScoreRing -----
function scoreTier(score) {
  if (score >= 85) return { color: '#059669', track: '#D1FAE5', label: 'Strong' };  // green
  if (score >= 70) return { color: '#2563EB', track: '#DBEAFE', label: 'Good'   };  // blue
  if (score >= 55) return { color: '#CA8A04', track: '#FEF9C3', label: 'Fair'   };  // yellow
  return                 { color: '#9CA3AF', track: '#E5E7EB', label: 'Weak'   };
}
const ScoreRing = ({ score = 0, size = 56, stroke = 5, showLabel = true }) => {
  const tier = scoreTier(score);
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(100, Math.max(0, score)) / 100) * c;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size/2} cy={size/2} r={r} stroke={tier.track} strokeWidth={stroke} fill="none"/>
        <circle
          cx={size/2} cy={size/2} r={r}
          stroke={tier.color} strokeWidth={stroke} fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          className="ring-anim"
          style={{ ['--from']: c, ['--to']: offset }}
        />
      </svg>
      {showLabel && (
        <div className="absolute inset-0 flex flex-col items-center justify-center leading-none">
          <span className="num font-semibold text-ink-900" style={{ fontSize: size * 0.32 }}>{score}</span>
          <span className="text-[9px] uppercase tracking-wider text-ink-500 mt-0.5" style={{ letterSpacing: '0.08em' }}>{tier.label}</span>
        </div>
      )}
    </div>
  );
};

// ----- ReasonTag -----
const ReasonTag = ({ kind, label }) => {
  const map = {
    skill: { tone: 'success', dot: '#10B981' },
    exp:   { tone: 'brand',   dot: '#2563EB' },
    loc:   { tone: 'brand',   dot: '#3B82F6' },
    neg:   { tone: 'warn',    dot: '#EAB308' },
  };
  const m = map[kind] || map.skill;
  return (
    <Pill tone={m.tone} className="!h-7 !text-[11.5px] !px-2.5">
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: m.dot }}/>
      {label}
    </Pill>
  );
};

// ----- MiniBars -----
const MiniBars = ({ data = [], color = '#2563EB' }) => {
  const max = Math.max(1, ...data);
  return (
    <div className="flex items-end gap-[3px] h-6">
      {data.map((v, i) => (
        <span key={i} className="w-[3px] rounded-sm" style={{ height: `${(v/max)*100}%`, background: color, opacity: 0.35 + (v/max)*0.6 }}/>
      ))}
    </div>
  );
};

// ----- Card -----
const Card = ({ children, className = '', as: As = 'section', ...rest }) => (
  <As className={`bg-paper-0 border border-paper-200 rounded-2xl shadow-card ${className}`} {...rest}>
    {children}
  </As>
);

const SectionLabel = ({ children, className = '' }) => (
  <div className={`text-[11px] uppercase tracking-[0.12em] text-ink-500 font-semibold ${className}`}>{children}</div>
);

const SectionHead = ({ kicker, title, sub, right }) => (
  <header className="flex items-end justify-between gap-6 mb-5">
    <div>
      {kicker && <SectionLabel>{kicker}</SectionLabel>}
      <h2 className="display text-[28px] leading-[1.1] mt-1.5 text-ink-900 font-semibold">{title}</h2>
      {sub && <p className="text-[14px] text-ink-600 mt-1.5 max-w-[58ch]">{sub}</p>}
    </div>
    {right && <div className="shrink-0">{right}</div>}
  </header>
);

Object.assign(window, {
  Logo, StatusDot, Pill, Button, IconBtn, Toggle, Skeleton,
  ScoreRing, ReasonTag, MiniBars, Card, SectionLabel, SectionHead,
  scoreTier,
});
