// Applications tab — Tracker.

const STAGE_TONE_MAP = {
  submitted: { dot: 'muted',   pill: 'default', text: 'text-ink-600' },
  viewed:    { dot: 'primary', pill: 'sky',     text: 'text-[#2E5AAC]' },
  screening: { dot: 'primary', pill: 'sky',     text: 'text-[#2E5AAC]' },
  interview: { dot: 'success', pill: 'forest',  text: 'text-[#1F5236]' },
  offer:     { dot: 'success', pill: 'forest',  text: 'text-[#1F5236]' },
  rejected:  { dot: 'muted',   pill: 'default', text: 'text-ink-500' },
};

const STAGE_ORDER = ['submitted','viewed','screening','interview','offer'];

const StageTimeline = ({ stage }) => {
  const isRejected = stage === 'rejected';
  const idx = STAGE_ORDER.indexOf(stage);
  return (
    <div className="flex items-center gap-1">
      {STAGE_ORDER.map((s, i) => {
        const reached = !isRejected && i <= idx;
        const isActive = !isRejected && i === idx;
        return (
          <span
            key={s}
            className={`h-1 rounded-full transition-all ${
              isActive ? 'w-5 bg-ink-900' :
              reached ? 'w-3 bg-ink-700' :
              'w-3 bg-paper-200'
            } ${isRejected ? 'bg-paper-200' : ''}`}
            title={STAGE_META[s].label}
          />
        );
      })}
    </div>
  );
};

const ApplicationRow = ({ app }) => {
  const meta = STAGE_META[app.stage];
  const tone = STAGE_TONE_MAP[app.stage];
  return (
    <div className="grid grid-cols-12 items-center gap-4 px-5 py-4 hover:bg-paper-50 transition-colors">
      <div className="col-span-1 flex justify-center">
        <StatusDot tone={tone.dot} pulse={meta.pulse} size={10}/>
      </div>
      <div className="col-span-5 min-w-0">
        <div className="text-[14px] font-medium text-ink-900 truncate">{app.title}</div>
        <div className="text-[12.5px] text-ink-500 truncate">{app.company}</div>
      </div>
      <div className="col-span-3">
        <Pill tone={tone.pill}>
          <StatusDot tone={tone.dot} pulse={meta.pulse} size={6}/>
          {meta.label}
        </Pill>
      </div>
      <div className="col-span-2">
        <StageTimeline stage={app.stage}/>
      </div>
      <div className="col-span-1 text-right text-[12px] text-ink-500 num">{app.when}</div>
    </div>
  );
};

const Tracker = ({ apps }) => {
  const active = apps.filter(a => a.stage !== 'rejected').length;
  return (
    <div className="anim-fade">
      <SectionHead
        kicker="Applications"
        title="Everything you've sent."
        sub={`${active} active · synced with the connected ATS.`}
        right={
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="md" icon={<I.Plus size={14}/>}>Log manual</Button>
            <Button variant="primary"   size="md" icon={<I.Refresh size={14}/>}>Sync now</Button>
          </div>
        }
      />

      <Card className="overflow-hidden">
        <div className="grid grid-cols-12 gap-4 px-5 py-3 bg-paper-50 border-b border-paper-200 text-[10.5px] uppercase tracking-[0.14em] text-ink-500 font-medium">
          <div className="col-span-1 text-center">·</div>
          <div className="col-span-5">Role</div>
          <div className="col-span-3">Stage</div>
          <div className="col-span-2">Progress</div>
          <div className="col-span-1 text-right">When</div>
        </div>
        <div className="divide-y divide-paper-200">
          {apps.map(a => <ApplicationRow key={a.id} app={a}/>)}
        </div>
      </Card>
    </div>
  );
};

Object.assign(window, { Tracker, ApplicationRow });
